# TEMASA – Assistant de données (Streamlit)

Application web en français pour interroger la base `temasa_dw` (production, qualité, commandes, stock) :

| Page | Contenu | Qui |
|---|---|---|
| **app** (accueil) | Tableau de bord : 4 KPI avec variation vs période précédente, filtres date/machine, graphiques | tous |
| **Assistant** | Chat : questions en français → SQL **lecture seule** → réponse, tableau, graphique, CSV | tous |
| **Prevision ML** | Prévision de production, facteurs du rebut (régression), classification (rebut élevé / livraison en retard), anomalies | tous en lecture ; **admin** pour entraîner |
| **Administration** | État de la configuration, tests (base, clé, compte SQL), comptes, modèles enregistrés | **admin** |

Tout tourne en local. Seul l'assistant appelle un modèle de langage (Gemini gratuit ou Claude). Le Machine Learning utilise
scikit-learn / statsmodels : **aucun coût**.

---

## 1. Installation (Windows PowerShell)

Prérequis : Python 3.11, « ODBC Driver 17 for SQL Server », et la base `temasa_dw` déjà chargée
(`temasa_schema.sql` puis `clean_and_load.py`).

```powershell
cd C:\Users\hp\Downloads\temasa_app          # le dossier de ce projet
python -m venv .venv
.\.venv\Scripts\Activate.ps1                  # si PowerShell refuse : Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
python -m pip install -r requirements.txt
```

## 2. Configuration (faite par l'administrateur, jamais dans l'interface)

```powershell
copy .env.example .env
notepad .env
```

Renseignez dans `.env` :

* **La clé du modèle de langage** (voir §3).
* **La base** : `DB_SERVER=LAPTOP-AN5ESP2Q\DS` (le résultat de `SELECT @@SERVERNAME` dans SSMS), `DB_NAME=temasa_dw`.
  Laissez `DB_USER` / `DB_PASSWORD` vides pour l'authentification Windows, ou utilisez le compte lecture seule (§5).

Alternative : copier `.streamlit/secrets.toml.example` en `.streamlit/secrets.toml` (prioritaire sur `.env` ; en TOML, doublez
la barre oblique : `"LAPTOP-AN5ESP2Q\\DS"`).
`.env`, `secrets.toml`, `config.yaml` et `models/*.joblib` sont dans `.gitignore` : ne les publiez jamais.

## 3. La clé API (erreur « 401 invalid x-api-key »)

Cette erreur signifie que la clé est absente, mal copiée ou refusée. L'application la nettoie (espaces, guillemets, `Bearer`),
la vérifie **avant** tout appel et affiche un message en français. Le fournisseur se choisit avec `LLM_PROVIDER` :

* **`gemini` (gratuit, par défaut)** : ouvrez <https://aistudio.google.com/apikey>, connectez-vous avec un compte Google,
  « Create API key », puis dans `.env` : `GEMINI_API_KEY=AIza...`. Le quota gratuit est limité (message « Limite
  atteinte » → attendez une minute). Vérifiez les conditions d'utilisation du palier gratuit avant d'envoyer des données
  confidentielles ; avec les données fictives de ce projet, aucun souci.
* **`anthropic` (payant)** : <https://console.anthropic.com> → ajouter du crédit → API keys → `ANTHROPIC_API_KEY=sk-ant-...`.
  L'abonnement Claude.ai ne donne pas de clé API.

Changer de fournisseur = changer **une ligne** (`LLM_PROVIDER`) puis redémarrer. Le fichier `llm.py` est le seul à connaître les fournisseurs.
Si le nom du modèle est refusé : `GEMINI_MODEL=...` ou `ANTHROPIC_MODEL=...` dans `.env`.

## 4. Premier compte administrateur, puis lancement

```powershell
python create_user.py                  # le premier compte créé est administrateur (mot de passe haché bcrypt)
python -m streamlit run app.py
```

Autres commandes : `python create_user.py --list`, `--unlock NOM` (compte bloqué après 5 échecs), `--delete NOM`.
Rôles : **admin** (tout) et **utilisateur** (assistant, tableau de bord, lecture des modèles ; ni administration ni entraînement).
Le verrouillage est enregistré dans `config.yaml` : il survit à un rechargement de la page et reste actif jusqu'au déverrouillage.

## 5. Sécurité : SQL en lecture seule

Le SQL est écrit par un modèle de langage : on ne lui fait pas confiance. Trois protections empilées :

1. **`sql_guard.py`** : analyse réelle de la requête (sqlglot, T-SQL). Une seule instruction `SELECT` / `WITH … SELECT` ; refus de
   `; INSERT UPDATE DELETE DROP ALTER CREATE EXEC MERGE TRUNCATE INTO`, des commentaires, des variables, des procédures système,
   de `sys.*`, `INFORMATION_SCHEMA`, `OPENROWSET`… ; **seules les tables et vues du projet** sont lisibles ; `TOP 500` imposé.
2. **Limites** : 500 lignes (aussi côté client) et 30 s par requête (`SQL_MAX_ROWS`, `SQL_TIMEOUT_SECONDS`).
3. **Compte SQL limité à SELECT** (la vraie barrière) : exécutez `sql/create_readonly_user.sql` dans SSMS, puis mettez
   `DB_USER=temasa_reader` et `DB_PASSWORD=...` dans `.env` (le serveur doit accepter l'authentification SQL / mode mixte).
   La page Administration → « Vérifier le compte SQL » signale un compte qui peut écrire.

La chaîne de connexion, le mot de passe et les clés ne sont jamais affichés (les messages d'erreur sont nettoyés par `settings.redact`).

## 6. Prévision & ML : ce que font les modèles

* **Méthode** : découpage **temporel** (entraînement sur le passé, test sur les 20 % les plus récents, pas de fuite de données),
  validation croisée à fenêtre croissante, comparaison à une référence (moyenne). Moins de données que nécessaire → refus avec un message clair.
* **Prévision** : régression linéaire (tendance + saisonnalité, bande de confiance 95 %) comparée à Random Forest et Gradient Boosting.
  Avec moins de deux années de données, la saisonnalité annuelle n'est pas validable : un avertissement s'affiche.
* **Facteurs du rebut** : régression linéaire multiple (écarts-types robustes) : coefficients, p-values, R², explications en français.
* **Classification** : régression logistique et Random Forest, matrice de confusion, précision / rappel, courbe ROC, importance des variables.
* **Anomalies** : IsolationForest ; chaque machine est comparée à ses propres habitudes.
* Les modèles et leurs résultats sont enregistrés dans `models/` avec la date d'entraînement. Seul un admin peut réentraîner.

Avec les **données fictives** du projet : le rebut est très prévisible (machines MC-04 et MC-08), mais les retards de livraison sont
aléatoires dans le jeu de données : le modèle « livraison en retard » indique honnêtement qu'il ne fait pas mieux que le hasard.

## 7. Tests

```powershell
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

`tests/test_sql_guard.py` vérifie que les requêtes dangereuses sont rejetées ; `test_llm.py` la validation des clés et les messages d'erreur ;
`test_ml.py` la méthode (pas de fuite temporelle, refus si trop peu de données, détection d'une anomalie injectée).

## 8. Structure

```
app.py                  tableau de bord (accueil)         auth.py     connexion, rôles, verrouillage
pages/1_Assistant.py    chat SQL                          db.py       connexion SQL, requêtes, chargement, caches
pages/2_Prevision_ML.py régression / ML                   llm.py      fournisseur de modèle (Gemini / Anthropic), prompts
pages/3_Administration.py                                 sql_guard.py  garde-fou SQL
ml.py                   modèles                           charts.py   graphiques Plotly
settings.py             .env / secrets                    create_user.py  gestion des comptes
sql/create_readonly_user.sql   tests/   models/   config.example.yaml   .env.example
```

## 9. Dépannage

| Message | Cause / solution |
|---|---|
| « Aucun compte n'existe encore » | Lancez `python create_user.py`. |
| « Compte verrouillé » | `python create_user.py --unlock NOM` ou Administration → Déverrouiller. |
| « Serveur SQL introuvable » | Vérifiez `DB_SERVER` (`MACHINE\INSTANCE`) et que le service SQL Server est démarré. |
| « Pilote ODBC introuvable » | Installez *ODBC Driver 17 for SQL Server* ou changez `DB_DRIVER`. |
| « Limite d'utilisation atteinte » | Quota gratuit Gemini : patientez une minute. |
| Le menu latéral affiche « app » | C'est la page d'accueil (le tableau de bord) : Streamlit nomme l'entrée d'après le fichier `app.py`. |
