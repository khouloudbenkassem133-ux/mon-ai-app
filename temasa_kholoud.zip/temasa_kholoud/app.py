"""
TEMASA - Tableau de bord (page d'accueil).
Lancer :  python -m streamlit run app.py
"""
import pandas as pd
import streamlit as st

import auth
import charts
import db

st.set_page_config(page_title="TEMASA – Tableau de bord", page_icon="🧦", layout="wide")
auth.require_login()

st.title("🧦 TEMASA – Tableau de bord")

if not db.is_configured():
    st.error("La base de données n'est pas configurée. Un administrateur doit renseigner DB_SERVER / DB_NAME "
             "(ou DB_URL) dans le fichier .env ou .streamlit/secrets.toml (voir README).")
    st.stop()
missing = db.missing_tables()
if missing:
    st.error("Tables introuvables dans la base : " + ", ".join(missing) + ". Exécutez temasa_schema.sql puis clean_and_load.py.")
    st.stop()
try:
    prod, qual, orders, stock = db.load_production(), db.load_quality(), db.load_orders(), db.load_stock()
except Exception as e:
    st.error(db.friendly_error(e))
    st.stop()
if prod.empty:
    st.warning("La table de production est vide.")
    st.stop()

dmin, dmax = prod["date"].min().normalize(), prod["date"].max().normalize()


def fr(n, d=0):
    return f"{n:,.{d}f}".replace(",", " ")


# ----------------------------------------------------------------------------- filtres
with st.sidebar:
    st.header("Filtres")
    choice = st.selectbox("Période", ["Dernier mois des données", "3 derniers mois", "Année en cours", "Toute la période", "Personnalisée"])
    if choice == "Dernier mois des données":
        start, end = dmax.replace(day=1), dmax
    elif choice == "3 derniers mois":
        start, end = (dmax - pd.DateOffset(months=3) + pd.Timedelta(days=1)).normalize(), dmax
    elif choice == "Année en cours":
        start, end = pd.Timestamp(dmax.year, 1, 1), dmax
    elif choice == "Toute la période":
        start, end = dmin, dmax
    else:
        rng = st.date_input("Du … au …", (dmax.replace(day=1).date(), dmax.date()), min_value=dmin.date(), max_value=dmax.date())
        start, end = (pd.Timestamp(rng[0]), pd.Timestamp(rng[-1])) if len(rng) else (dmin, dmax)
    machines = st.multiselect("Machines", sorted(prod["machine_code"].unique()), placeholder="Toutes les machines")
    st.caption("Le filtre machines s'applique à la production, au rebut et aux défauts.")

span = end - start
p_end, p_start = start - pd.Timedelta(days=1), start - pd.Timedelta(days=1) - span
has_prev = p_start >= dmin and choice != "Toute la période"

pf = prod if not machines else prod[prod["machine_code"].isin(machines)]
qf = qual if not machines else qual[qual["machine_code"].isin(machines)]


def between(df, col, a, b):
    return df[(df[col] >= a) & (df[col] <= b + pd.Timedelta(hours=23, minutes=59))]


cur, prev = between(pf, "date", start, end), between(pf, "date", p_start, p_end)


def rate(df):
    return 100.0 * df["qty_rejected"].sum() / df["qty_produced"].sum() if df["qty_produced"].sum() else float("nan")


def ontime(a, b):
    d = between(orders.dropna(subset=["delivery_date", "due_date"]), "delivery_date", a, b)
    return (100.0 * (d["delivery_date"] <= d["due_date"]).mean(), len(d)) if len(d) else (float("nan"), 0)


snap_dates = sorted(stock.loc[stock["date"] <= end, "date"].unique())


def critical(date):
    s = stock[stock["date"] == date]
    return int((s["qty_on_hand"] < s["min_stock_level"]).sum())


st.caption(f"Période : **{start:%d/%m/%Y} → {end:%d/%m/%Y}**" + (f" · comparée à {p_start:%d/%m/%Y} → {p_end:%d/%m/%Y}" if has_prev else "")
           + f" · données jusqu'au {dmax:%d/%m/%Y}")

# ----------------------------------------------------------------------------- cartes KPI
c1, c2, c3, c4 = st.columns(4)
prod_cur, prod_prev = cur["qty_produced"].sum(), prev["qty_produced"].sum()
with c1:
    st.metric("Production de la période", fr(prod_cur), f"{(prod_cur / prod_prev - 1) * 100:+.1f} % vs période précédente" if has_prev and prod_prev else None, border=True)
r_cur, r_prev = rate(cur), rate(prev)
with c2:
    st.metric("Taux de rebut", f"{r_cur:.2f} %" if r_cur == r_cur else "—",
              f"{r_cur - r_prev:+.2f} pt" if has_prev and r_cur == r_cur and r_prev == r_prev else None, delta_color="inverse", border=True)
o_cur, n_cur = ontime(start, end)
o_prev, _ = ontime(p_start, p_end)
with c3:
    st.metric("Livraison à temps", f"{o_cur:.1f} %" if o_cur == o_cur else "—",
              f"{o_cur - o_prev:+.1f} pt" if has_prev and o_cur == o_cur and o_prev == o_prev else None, border=True,
              help=f"{n_cur} lignes de commande livrées sur la période (livrée à la date d'échéance ou avant).")
with c4:
    if snap_dates:
        k_now = critical(snap_dates[-1])
        k_prev = critical(snap_dates[-2]) if len(snap_dates) > 1 else None
        st.metric("Produits en stock critique", k_now, f"{k_now - k_prev:+d} vs mois précédent" if k_prev is not None else None,
                  delta_color="inverse", border=True, help=f"Quantité en stock < stock minimum, au {pd.Timestamp(snap_dates[-1]):%d/%m/%Y}.")
    else:
        st.metric("Produits en stock critique", "—", border=True)

# ----------------------------------------------------------------------------- graphiques
a, b = st.columns(2)
with a:
    st.plotly_chart(charts.monthly_production(pf), width="stretch")
with b:
    if len(cur):
        st.plotly_chart(charts.reject_by_machine(cur), width="stretch")
    else:
        st.info("Aucune production sur la période choisie.")
a, b = st.columns(2)
with a:
    qcur = between(qf, "date", start, end)
    if len(qcur):
        st.plotly_chart(charts.pareto_defects(qcur), width="stretch")
    else:
        st.info("Aucun défaut enregistré sur la période.")
with b:
    st.plotly_chart(charts.ontime_by_month(orders), width="stretch")
a, b = st.columns(2)
with a:
    od = between(orders.dropna(subset=["delivery_date"]), "delivery_date", start, end)
    if len(od):
        st.plotly_chart(charts.revenue_by_country(od), width="stretch")
    else:
        st.info("Aucune livraison sur la période.")
with b:
    st.subheader("Stock critique")
    if snap_dates:
        s = stock[stock["date"] == snap_dates[-1]].copy()
        s = s[s["qty_on_hand"] < s["min_stock_level"]]
        s["Écart"] = s["qty_on_hand"] - s["min_stock_level"]
        st.caption(f"Instantané du {pd.Timestamp(snap_dates[-1]):%d/%m/%Y}")
        if s.empty:
            st.success("Aucun produit sous le stock minimum.")
        else:
            st.dataframe(s.sort_values("Écart")[["product_code", "product_name", "qty_on_hand", "min_stock_level", "Écart"]]
                         .rename(columns={"product_code": "Code", "product_name": "Produit", "qty_on_hand": "En stock", "min_stock_level": "Minimum"}),
                         width="stretch", hide_index=True, height=300)
