"""
Authentification : streamlit-authenticator (mots de passe bcrypt, cookie de session, rôles, verrouillage).

Utilisateurs dans config.yaml (hors Git) - ajoutez-en avec :  python create_user.py
Rôles : "admin" (tout) et "utilisateur" (assistant + tableaux de bord + lecture des modèles).
Chaque page appelle require_login() en premier : rien ne s'affiche tant que l'utilisateur n'est pas connecté.
"""
import yaml
import streamlit as st
import streamlit_authenticator as stauth
from streamlit_authenticator.utilities import LoginError

import settings

CONFIG_PATH = settings.BASE_DIR / "config.yaml"
MAX_ATTEMPTS = settings.get_int("MAX_LOGIN_ATTEMPTS", 5)
FIELDS = {"Form name": "Connexion – TEMASA", "Username": "Nom d'utilisateur", "Password": "Mot de passe",
          "Login": "Se connecter", "Captcha": "Captcha"}


def load_config():
    if not CONFIG_PATH.exists():
        return None
    with open(CONFIG_PATH, encoding="utf-8") as f:
        return yaml.safe_load(f)


def config_problem(cfg):
    """Message d'erreur si la configuration est absente, vide ou contient un mot de passe en clair."""
    if cfg is None:
        return "Aucun compte n'existe encore."
    users = (cfg.get("credentials") or {}).get("usernames") or {}
    if not users:
        return "Le fichier config.yaml ne contient aucun utilisateur."
    for name, u in users.items():
        if not stauth.Hasher.is_hash(str(u.get("password", ""))):
            return f"Le mot de passe de « {name} » n'est pas haché (bcrypt). Recréez le compte avec create_user.py."
    return None


def is_admin() -> bool:
    return "admin" in (st.session_state.get("roles") or [])


def current_user() -> str:
    return st.session_state.get("username") or ""


def require_login(admin_only: bool = False):
    """À appeler en tout début de page. Affiche la connexion, ou arrête la page (st.stop)."""
    cfg = load_config()
    problem = config_problem(cfg)
    if problem:
        st.title("🔒 TEMASA")
        st.error(problem)
        st.markdown("Créez le premier compte administrateur depuis le dossier de l'application :\n\n"
                    "```\npython create_user.py\n```\nPuis rechargez cette page.")
        st.stop()

    authenticator = stauth.Authenticate(str(CONFIG_PATH), auto_hash=False)
    if not st.session_state.get("authentication_status"):
        st.title("🧦 TEMASA – Assistant de données")
    try:
        authenticator.login(location="main", max_login_attempts=MAX_ATTEMPTS, fields=FIELDS)
    except LoginError:
        st.error(f"🔒 Compte verrouillé après {MAX_ATTEMPTS} tentatives échouées. "
                 "Demandez à un administrateur de le déverrouiller (`python create_user.py --unlock NOM`).")
        st.stop()

    status = st.session_state.get("authentication_status")
    if status is False:
        st.error("Nom d'utilisateur ou mot de passe incorrect.")
    if not status:
        if status is None:
            st.info("Veuillez vous connecter pour accéder à l'application.")
        st.stop()

    with st.sidebar:
        role = "administrateur" if is_admin() else "utilisateur"
        st.markdown(f"👤 **{st.session_state.get('name') or current_user()}**  \n*{role}*")
        authenticator.logout("Se déconnecter", "sidebar", key="logout_btn")
        st.divider()
    if admin_only and not is_admin():
        st.error("⛔ Cette page est réservée aux administrateurs.")
        st.stop()


def unlock_user(username: str) -> bool:
    cfg = load_config()
    u = ((cfg or {}).get("credentials") or {}).get("usernames", {}).get(username)
    if u is None:
        return False
    u["failed_login_attempts"] = 0
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, allow_unicode=True, sort_keys=False)
    return True


def users_table():
    cfg = load_config() or {}
    rows = []
    for name, u in ((cfg.get("credentials") or {}).get("usernames") or {}).items():
        rows.append({"Utilisateur": name, "Nom": f"{u.get('first_name', '')} {u.get('last_name', '')}".strip(),
                     "Rôle": ", ".join(u.get("roles") or []), "Tentatives échouées": int(u.get("failed_login_attempts", 0)),
                     "Verrouillé": int(u.get("failed_login_attempts", 0)) >= MAX_ATTEMPTS})
    return rows
