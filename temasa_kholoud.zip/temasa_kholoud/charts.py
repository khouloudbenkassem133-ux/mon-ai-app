"""Graphiques Plotly : palette unique, fonds transparents -> lisibles en thème clair ET sombre."""
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

BLUE, ORANGE, GREEN, RED, PURPLE, GREY = "#3B82F6", "#F59E0B", "#10B981", "#EF4444", "#8B5CF6", "#94A3B8"
PALETTE = [BLUE, ORANGE, GREEN, PURPLE, RED, "#06B6D4", "#EC4899"]
CAT_COLORS = {"Chaussettes": BLUE, "Collants": ORANGE}


def style(fig, height=340, legend=True):
    fig.update_layout(height=height, margin=dict(l=10, r=10, t=40, b=10), paper_bgcolor="rgba(0,0,0,0)",
                      plot_bgcolor="rgba(0,0,0,0)", showlegend=legend, legend=dict(orientation="h", y=-0.2),
                      colorway=PALETTE, hovermode="x unified")
    fig.update_xaxes(gridcolor="rgba(148,163,184,0.25)", zeroline=False)
    fig.update_yaxes(gridcolor="rgba(148,163,184,0.25)", zeroline=False)
    return fig


def _fr(n, d=0):
    return f"{n:,.{d}f}".replace(",", " ")


# ----------------------------------------------------------------------------- assistant : graphique automatique
def auto_chart(df: pd.DataFrame):
    """Graphique adapté au résultat d'une requête, ou None si ce n'est pas pertinent."""
    if df is None or df.empty or len(df) < 2 or len(df) > 60 or df.shape[1] < 2 or df.shape[1] > 4:
        return None
    nums = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    cats = [c for c in df.columns if c not in nums]
    if not nums:
        return None
    # une colonne "temps" (date, mois, aaaamm) -> courbe
    first = df.columns[0]
    timey = pd.api.types.is_datetime64_any_dtype(df[first]) or any(k in str(first).lower() for k in ("mois", "month", "date", "ym", "annee", "année", "year", "semaine", "week"))
    if first in nums and not timey:
        return None
    if timey:
        y = [c for c in nums if c != first]
        if not y:
            return None
        d = df.copy()
        d[first] = d[first].astype(str)
        return style(px.line(d, x=first, y=y, markers=True))
    if len(cats) == 1:
        return style(px.bar(df, x=cats[0], y=nums[:3], barmode="group"), legend=len(nums) > 1)
    if len(cats) == 2 and len(nums) >= 1:
        return style(px.bar(df, x=cats[0], y=nums[0], color=cats[1], barmode="group"))
    return None


# ----------------------------------------------------------------------------- tableau de bord
def monthly_production(prod: pd.DataFrame):
    d = prod.assign(mois=prod["date"].dt.to_period("M").dt.start_time).groupby(["mois", "category"], as_index=False)["qty_produced"].sum()
    fig = px.area(d, x="mois", y="qty_produced", color="category", color_discrete_map=CAT_COLORS,
                  labels={"mois": "", "qty_produced": "Quantité produite", "category": "Catégorie"},
                  title="Production mensuelle par catégorie")
    return style(fig)


def reject_by_machine(prod: pd.DataFrame, alert=4.0):
    g = prod.groupby("machine_code").agg(p=("qty_produced", "sum"), r=("qty_rejected", "sum"))
    g["taux"] = 100.0 * g["r"] / g["p"]
    g = g.sort_values("taux", ascending=False).reset_index()
    fig = go.Figure(go.Bar(x=g["machine_code"], y=g["taux"], marker_color=[RED if v >= alert else BLUE for v in g["taux"]],
                           hovertemplate="%{x}: %{y:.2f} %<extra></extra>"))
    fig.update_layout(title=f"Taux de rebut par machine (rouge ≥ {alert:.0f} %)", yaxis_title="Taux de rebut (%)")
    return style(fig, legend=False)


def pareto_defects(q: pd.DataFrame):
    g = q.groupby("defect_name")["qty_defective"].sum().sort_values(ascending=False)
    cum = 100 * g.cumsum() / g.sum()
    fig = go.Figure()
    fig.add_bar(x=g.index, y=g.values, name="Défauts", marker_color=BLUE)
    fig.add_scatter(x=g.index, y=cum.values, name="Cumul %", yaxis="y2", mode="lines+markers", line=dict(color=ORANGE))
    fig.update_layout(title="Défauts les plus fréquents (Pareto)", yaxis=dict(title="Quantité"),
                      yaxis2=dict(title="Cumul (%)", overlaying="y", side="right", range=[0, 105], showgrid=False))
    return style(fig)


def ontime_by_month(orders: pd.DataFrame):
    d = orders.dropna(subset=["delivery_date", "due_date"]).copy()
    d["mois"] = d["delivery_date"].dt.to_period("M").dt.start_time
    d["a_temps"] = (d["delivery_date"] <= d["due_date"]).astype(int)
    g = d.groupby("mois")["a_temps"].mean().mul(100).reset_index()
    fig = px.line(g, x="mois", y="a_temps", markers=True, labels={"mois": "", "a_temps": "Livraison à temps (%)"},
                  title="Livraison à temps par mois")
    fig.add_hline(y=90, line_dash="dot", line_color=GREEN, annotation_text="objectif 90 %")
    fig.update_yaxes(range=[0, 105])
    return style(fig, legend=False)


def revenue_by_country(orders: pd.DataFrame):
    g = orders.groupby("country", as_index=False)["revenue"].sum().sort_values("revenue")
    fig = px.bar(g, x="revenue", y="country", orientation="h", labels={"revenue": "Chiffre d'affaires (MAD)", "country": ""},
                 title="Chiffre d'affaires livré par pays", color_discrete_sequence=[GREEN])
    return style(fig, legend=False)


# ----------------------------------------------------------------------------- ML
def forecast_fig(res: dict, model: str):
    s, fc, tp = res["series"], res["forecasts"][model], res["test_pred"]
    unit = {"production": "Production", "rebut": "Rebut", "taux_rebut": "Taux de rebut (%)"}[res["target"]]
    fig = go.Figure()
    fig.add_scatter(x=s["periode"], y=s["valeur"], name="Historique", mode="lines", line=dict(color=BLUE))
    if model in tp.columns:
        fig.add_scatter(x=tp["periode"], y=tp[model], name="Prédit sur le test (non vu à l'entraînement)", mode="lines",
                        line=dict(color=GREEN, dash="dot"))
    fig.add_traces([go.Scatter(x=list(fc["periode"]) + list(fc["periode"])[::-1], y=list(fc["haut"]) + list(fc["bas"])[::-1],
                               fill="toself", fillcolor="rgba(245,158,11,0.2)", line=dict(width=0), name="Intervalle 95 %", hoverinfo="skip")])
    fig.add_scatter(x=fc["periode"], y=fc["prevision"], name="Prévision", mode="lines+markers", line=dict(color=ORANGE))
    cutoff = tp["periode"].min()
    fig.add_vline(x=cutoff, line_dash="dash", line_color=GREY)
    fig.add_annotation(x=cutoff, y=1, yref="paper", text="début du test", showarrow=False, yanchor="bottom")
    fig.update_layout(title=f"{unit} : historique et prévision ({model})")
    return style(fig, height=420)


def coef_fig(coefs: pd.DataFrame):
    d = coefs.sort_values("Coefficient (points de %)")
    d = d.assign(sig=np.where(d["p-value"] < 0.05, "Significatif (p < 0,05)", "Non significatif"))
    fig = px.scatter(d, x="Coefficient (points de %)", y="Variable", color="sig",
                     color_discrete_map={"Significatif (p < 0,05)": RED, "Non significatif": GREY},
                     error_x=d["IC 95 % haut"] - d["Coefficient (points de %)"],
                     error_x_minus=d["Coefficient (points de %)"] - d["IC 95 % bas"],
                     title="Effet de chaque variable sur le taux de rebut (points de %, IC 95 %)")
    fig.add_vline(x=0, line_color=GREY)
    return style(fig, height=max(320, 26 * len(d) + 120))


def confusion_fig(cm, labels):
    z = np.array(cm)
    fig = px.imshow(z, x=[f"Prédit : {l}" for l in labels], y=[f"Réel : {l}" for l in labels], text_auto=True,
                    color_continuous_scale=[[0, "rgba(59,130,246,0.08)"], [1, BLUE]], title="Matrice de confusion (période de test)")
    fig.update_coloraxes(showscale=False)
    return style(fig, height=320, legend=False)


def roc_fig(roc: dict, auc: float):
    fig = go.Figure()
    fig.add_scatter(x=roc["fpr"], y=roc["tpr"], mode="lines", name=f"Modèle (AUC = {auc:.2f})", line=dict(color=BLUE, width=3))
    fig.add_scatter(x=[0, 1], y=[0, 1], mode="lines", name="Hasard (AUC = 0,50)", line=dict(color=GREY, dash="dash"))
    fig.update_layout(title="Courbe ROC", xaxis_title="Faux positifs", yaxis_title="Vrais positifs")
    return style(fig, height=320)


def importance_fig(imp: pd.DataFrame):
    d = imp.head(10).sort_values("Importance")
    fig = px.bar(d, x="Importance", y="Variable", orientation="h", color_discrete_sequence=[PURPLE],
                 title="Importance des variables (baisse du score si on les mélange)")
    return style(fig, height=320, legend=False)


def anomaly_fig(allr: pd.DataFrame, machine: str, feat: str, label: str):
    d = allr[allr["machine_code"] == machine].sort_values("date")
    a = d[d["anomalie"]]
    fig = go.Figure()
    fig.add_scatter(x=d["date"], y=d[feat], mode="lines", name=label, line=dict(color=BLUE, width=1))
    fig.add_scatter(x=a["date"], y=a[feat], mode="markers", name="Anomalie", marker=dict(color=RED, size=9, symbol="diamond"))
    fig.update_layout(title=f"{machine} : {label} (anomalies en rouge)")
    return style(fig)


def residual_fig(res_df: pd.DataFrame):
    fig = px.scatter(res_df, x="ajuste", y="residu", opacity=0.4, color_discrete_sequence=[BLUE],
                     labels={"ajuste": "Taux de rebut estimé (%)", "residu": "Résidu"}, title="Résidus du modèle (doivent former un nuage sans forme)")
    fig.add_hline(y=0, line_color=GREY)
    return style(fig, height=300, legend=False)
