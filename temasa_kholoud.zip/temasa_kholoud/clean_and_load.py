#!/usr/bin/env python3
"""
TEMASA - Step 1 (analyze + clean the Excel) and Step 2 (load into the SQL database).

Install:   pip install pandas openpyxl sqlalchemy pyodbc
Dry run:   python clean_and_load.py --excel temasa_data.xlsx --dry-run
           -> cleans the data, prints a report, writes clean CSV files in ./clean_csv/
Load:      python clean_and_load.py --excel temasa_data.xlsx --reset \
             --url "mssql+pyodbc://@localhost/temasa_dw?driver=ODBC+Driver+17+for+SQL+Server&trusted_connection=yes"

Run temasa_schema.sql in SQL Server first (it creates the tables and fills dim_date / dim_shift).
"""
import argparse
import unicodedata
from datetime import date, datetime
from pathlib import Path

import pandas as pd

SHIFT_KEYS = {"Matin": 1, "Après-midi": 2, "Nuit": 3}   # same as dim_shift in the SQL script

# Canonical spelling of each defect (key = lower case, no accents)
DEFECT_LABELS = {
    "maille filee": "Maille filée", "trou": "Trou", "fil casse": "Fil cassé",
    "defaut de couture": "Défaut de couture", "pointe mal fermee": "Pointe mal fermée",
    "defaut de teinture": "Défaut de teinture", "tache": "Tache",
    "taille non conforme": "Taille non conforme",
}


# ----------------------------------------------------------------- helpers
def strip_accents(text: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", text) if unicodedata.category(c) != "Mn")


def clean_code(s: pd.Series) -> pd.Series:
    """' mc 03 ' / 'mc-03' -> 'MC-03'"""
    return (s.astype("string").str.strip().str.upper()
             .str.replace(r"[\s_]+", "-", regex=True))


def to_date(s: pd.Series) -> pd.Series:
    """Real Excel dates AND text dates 'dd/mm/yyyy' -> datetime."""
    def parse(v):
        if v is None or (not isinstance(v, str) and pd.isna(v)):
            return pd.NaT
        if isinstance(v, (datetime, date, pd.Timestamp)):
            return pd.Timestamp(v)
        txt = str(v).strip()
        try:
            return pd.Timestamp(datetime.strptime(txt, "%d/%m/%Y"))
        except ValueError:
            return pd.to_datetime(txt, dayfirst=True, errors="coerce")
    return s.map(parse)


def to_int(s: pd.Series) -> pd.Series:
    """'1 250 ' / 1250 / '12' -> 1250 / 1250 / 12 (empty -> <NA>)"""
    txt = s.astype("string").str.replace(r"[^\d\-.,]", "", regex=True).str.replace(",", ".", regex=False)
    return pd.to_numeric(txt, errors="coerce").round().astype("Int64")


def clean_shift(s: pd.Series) -> pd.Series:
    def f(v):
        if pd.isna(v):
            return pd.NA
        k = strip_accents(str(v)).lower().strip()
        if k.startswith("mat"):
            return "Matin"
        if k.startswith("apres"):
            return "Après-midi"
        if k.startswith("nuit"):
            return "Nuit"
        return pd.NA
    return s.map(f)


def clean_defect(s: pd.Series) -> pd.Series:
    def f(v):
        if pd.isna(v):
            return pd.NA
        k = strip_accents(str(v)).lower().strip()
        k = " ".join(k.split())
        if k not in DEFECT_LABELS:
            print(f"  [warning] unknown defect name, add it to DEFECT_LABELS: {v!r}")
            return k.capitalize()
        return DEFECT_LABELS[k]
    return s.map(f)


def date_key(s: pd.Series) -> pd.Series:
    return (s.dt.year * 10000 + s.dt.month * 100 + s.dt.day).astype("Int64")


class Report:
    def __init__(self):
        self.lines = []

    def add(self, msg):
        self.lines.append(msg)
        print(msg)


# ----------------------------------------------------------------- cleaning
def clean_all(excel_path: str, rep: Report):
    x = pd.read_excel(excel_path, sheet_name=None)       # every sheet -> DataFrame
    rep.add("== 1. ANALYSIS OF THE RAW EXCEL ==")
    for name in ["Produits", "Machines", "Clients", "Production", "Qualite", "Commandes", "Stock"]:
        df = x[name]
        rep.add(f"  {name:<11} {len(df):>6} rows | empty cells: {int(df.isna().sum().sum())}")

    rep.add("\n== 2. CLEANING ==")
    # ---- dimensions
    prod = x["Produits"].copy()
    prod["product_code"] = clean_code(prod["Code_Produit"])
    prod = prod.drop_duplicates("product_code")
    dim_product = pd.DataFrame({
        "product_code": prod["product_code"],
        "product_name": prod["Designation"].str.strip(),
        "category": prod["Categorie"].str.strip().str.capitalize(),
        "target_group": prod["Public"].str.strip().str.capitalize(),
        "size": prod["Taille"].astype("string").str.strip(),
        "color": prod["Couleur"].str.strip(),
        "quality_grade": prod["Qualite"].str.strip(),
        "unit_cost": prod["Cout_Unitaire_MAD"].round(2),
    })
    dim_product.insert(0, "product_key", range(1, len(dim_product) + 1))

    mac = x["Machines"].copy()
    mac["machine_code"] = clean_code(mac["Code_Machine"])
    mac = mac.drop_duplicates("machine_code")
    dim_machine = pd.DataFrame({
        "machine_code": mac["machine_code"], "machine_type": mac["Type_Machine"].str.strip(),
        "department": mac["Atelier"].str.strip(), "capacity_per_shift": to_int(mac["Capacite_Equipe"]),
    })
    dim_machine.insert(0, "machine_key", range(1, len(dim_machine) + 1))

    cli = x["Clients"].copy()
    cli["client_code"] = clean_code(cli["Code_Client"])
    cli = cli.drop_duplicates("client_code")
    dim_client = pd.DataFrame({
        "client_code": cli["client_code"], "client_name": cli["Nom_Client"].str.strip(),
        "country": cli["Pays"].str.strip().str.title(), "segment": cli["Segment"].str.strip().str.capitalize(),
    })
    dim_client.insert(0, "client_key", range(1, len(dim_client) + 1))

    # ---- production
    p = x["Production"].copy()
    p["date"] = to_date(p["Date"])
    p["machine_code"] = clean_code(p["Machine"])
    p["shift_name"] = clean_shift(p["Equipe"])
    p["product_code"] = clean_code(p["Code_Produit"])
    for src, dst in [("Qte_Planifiee", "qty_planned"), ("Qte_Produite", "qty_produced"), ("Qte_Rebut", "qty_rejected")]:
        p[dst] = to_int(p[src])
    p["run_hours"], p["downtime_hours"] = p["Heures_Marche"], p["Heures_Arret"]
    n0 = len(p)
    p = p.dropna(subset=["date", "machine_code", "shift_name", "product_code", "qty_produced"])
    n_bad = n0 - len(p)
    p = p.drop_duplicates(["date", "machine_code", "shift_name"], keep="first")
    n_dup = n0 - n_bad - len(p)
    rep.add(f"  Production : {n_dup} duplicate rows removed, {n_bad} rows dropped (missing key field), "
            f"{int(p['qty_planned'].isna().sum())} blank qty_planned kept as NULL")
    p = p.merge(dim_product[["product_key", "product_code"]], on="product_code", how="left") \
         .merge(dim_machine[["machine_key", "machine_code"]], on="machine_code", how="left")
    orphan = int(p["product_key"].isna().sum() + p["machine_key"].isna().sum())
    p = p.dropna(subset=["product_key", "machine_key"])
    p["date_key"] = date_key(p["date"])
    p["shift_key"] = p["shift_name"].map(SHIFT_KEYS).astype("Int64")
    fact_production = p[["date_key", "product_key", "machine_key", "shift_key", "qty_planned",
                         "qty_produced", "qty_rejected", "run_hours", "downtime_hours"]].astype(
        {"product_key": "Int64", "machine_key": "Int64"})
    rep.add(f"  Production : {orphan} rows with unknown product/machine code removed")

    # ---- quality
    q = x["Qualite"].copy()
    q["date"] = to_date(q["Date"])
    q["machine_code"] = clean_code(q["Machine"])
    q["product_code"] = clean_code(q["Code_Produit"])
    q["defect_name"] = clean_defect(q["Type_Defaut"])
    q["defect_family"] = q["Famille_Defaut"].str.strip().str.capitalize()
    q["qty_defective"] = to_int(q["Qte_Defectueuse"])
    q = q.dropna(subset=["date", "product_code", "defect_name", "qty_defective"])
    dim_defect = (q[["defect_name", "defect_family"]].drop_duplicates("defect_name")
                  .sort_values("defect_name").reset_index(drop=True))
    dim_defect.insert(0, "defect_type_key", range(1, len(dim_defect) + 1))
    q = q.merge(dim_product[["product_key", "product_code"]], on="product_code", how="left") \
         .merge(dim_machine[["machine_key", "machine_code"]], on="machine_code", how="left") \
         .merge(dim_defect[["defect_type_key", "defect_name"]], on="defect_name", how="left")
    q = q.dropna(subset=["product_key"])
    q["date_key"] = date_key(q["date"])
    fact_quality = q[["date_key", "product_key", "machine_key", "defect_type_key", "qty_defective"]].astype(
        {"product_key": "Int64", "machine_key": "Int64", "defect_type_key": "Int64"})
    rep.add(f"  Qualite    : {len(dim_defect)} distinct defect types after spelling normalisation")

    # ---- orders
    o = x["Commandes"].copy()
    o["order_number"] = o["N_Commande"].astype("string").str.strip().str.upper()
    for src, dst in [("Date_Commande", "order_date"), ("Date_Echeance", "due_date"), ("Date_Livraison", "delivery_date")]:
        o[dst] = to_date(o[src])
    o["client_code"] = clean_code(o["Code_Client"])
    o["product_code"] = clean_code(o["Code_Produit"])
    o["qty_ordered"] = to_int(o["Qte_Commandee"])
    o["qty_delivered"] = to_int(o["Qte_Livree"]).fillna(0)
    o = o.dropna(subset=["order_number", "order_date", "qty_ordered"])
    o = o.merge(dim_client[["client_key", "client_code"]], on="client_code", how="left") \
         .merge(dim_product[["product_key", "product_code"]], on="product_code", how="left")
    o = o.dropna(subset=["client_key", "product_key"])
    o["order_date_key"], o["due_date_key"], o["delivery_date_key"] = (date_key(o["order_date"]),
                                                                    date_key(o["due_date"]), date_key(o["delivery_date"]))
    fact_orders = o[["order_number", "order_date_key", "due_date_key", "delivery_date_key", "client_key",
                     "product_key", "qty_ordered", "qty_delivered", "Prix_Unitaire_MAD"]].rename(
        columns={"Prix_Unitaire_MAD": "unit_price"}).astype({"client_key": "Int64", "product_key": "Int64"})

    # ---- stock
    s = x["Stock"].copy()
    s["date"] = to_date(s["Date_Stock"])
    s["product_code"] = clean_code(s["Code_Produit"])
    s = s.merge(dim_product[["product_key", "product_code"]], on="product_code", how="left").dropna(subset=["date", "product_key"])
    s["date_key"] = date_key(s["date"])
    fact_stock = pd.DataFrame({
        "date_key": s["date_key"], "product_key": s["product_key"].astype("Int64"),
        "qty_on_hand": to_int(s["Qte_En_Stock"]), "min_stock_level": to_int(s["Stock_Minimum"]),
    })

    tables = {"dim_product": dim_product, "dim_machine": dim_machine, "dim_client": dim_client,
              "dim_defect_type": dim_defect, "fact_production": fact_production, "fact_quality": fact_quality,
              "fact_orders": fact_orders, "fact_stock": fact_stock}

    rep.add("\n== 3. CLEAN RESULT (compare with SQL after loading) ==")
    for name, df in tables.items():
        rep.add(f"  {name:<16} {len(df):>6} rows")
    rep.add(f"  SUM qty_produced  = {int(fact_production['qty_produced'].sum()):,}")
    rep.add(f"  SUM qty_rejected  = {int(fact_production['qty_rejected'].sum()):,}")
    rep.add(f"  SUM qty_defective = {int(fact_quality['qty_defective'].sum()):,}   (must equal qty_rejected)")
    rep.add(f"  SUM qty_ordered   = {int(fact_orders['qty_ordered'].sum()):,}")
    rep.add(f"  SUM qty_delivered = {int(fact_orders['qty_delivered'].sum()):,}")
    return tables


# ----------------------------------------------------------------- loading
LOAD_ORDER = ["dim_product", "dim_machine", "dim_client", "dim_defect_type",
              "fact_production", "fact_quality", "fact_orders", "fact_stock"]


def load(tables, url: str, reset: bool):
    from sqlalchemy import create_engine, text
    kwargs = {"fast_executemany": True} if url.startswith("mssql") else {}
    engine = create_engine(url, **kwargs)
    if reset:
        with engine.begin() as conn:
            for t in reversed(LOAD_ORDER):                # facts first, then dimensions
                try:
                    conn.execute(text(f"DELETE FROM {t}"))
                except Exception:
                    pass                                   # table does not exist yet
    for name in LOAD_ORDER:
        tables[name].to_sql(name, engine, if_exists="append", index=False, chunksize=1000)
        print(f"  loaded {name:<16} {len(tables[name]):>6} rows")


def main():
    ap = argparse.ArgumentParser(description="Clean the TEMASA Excel file and load it into SQL")
    ap.add_argument("--excel", default="temasa_data.xlsx")
    ap.add_argument("--url", help="SQLAlchemy URL of the target database")
    ap.add_argument("--reset", action="store_true", help="empty the tables before loading")
    ap.add_argument("--dry-run", action="store_true", help="clean only, export CSV files, no database")
    a = ap.parse_args()

    rep = Report()
    tables = clean_all(a.excel, rep)

    if a.dry_run or not a.url:
        out = Path("clean_csv")
        out.mkdir(exist_ok=True)
        for name, df in tables.items():
            df.to_csv(out / f"{name}.csv", index=False, encoding="utf-8-sig")
        print(f"\nClean CSV files written to ./{out}/  (use --url to load them into the database)")
    else:
        print("\n== 4. LOADING INTO THE DATABASE ==")
        load(tables, a.url, a.reset)
        print("Done. Now run temasa_checks.sql.")


if __name__ == "__main__":
    main()
