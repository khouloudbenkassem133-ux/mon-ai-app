#!/usr/bin/env python3
"""
Gestion des comptes (fichier config.yaml, hors Git). Les mots de passe sont hachés avec bcrypt, jamais stockés en clair.

  python create_user.py                 ajoute ou met à jour un utilisateur (le premier compte devient administrateur)
  python create_user.py --visible       idem, mais le mot de passe s'affiche quand on le tape (si la saisie masquée échoue)
  python create_user.py --list          liste les comptes
  python create_user.py --unlock NOM    déverrouille un compte bloqué après trop d'échecs
  python create_user.py --delete NOM    supprime un compte
"""
import argparse
import getpass
import secrets
import sys
from pathlib import Path

import yaml
from streamlit_authenticator import Hasher

CONFIG = Path(__file__).resolve().parent / "config.yaml"


def load():
    if CONFIG.exists():
        return yaml.safe_load(CONFIG.read_text(encoding="utf-8")) or {}
    return {}


def save(cfg):
    CONFIG.write_text(yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False), encoding="utf-8")


def ensure_structure(cfg):
    cfg.setdefault("credentials", {}).setdefault("usernames", {})
    cfg.setdefault("cookie", {"name": "temasa_auth", "key": secrets.token_hex(32), "expiry_days": 7})
    return cfg


def read_secret(prompt, visible=False):
    """Saisie masquée (getpass). Si le terminal ne la supporte pas (cas fréquent sous Windows), saisie visible."""
    if visible:
        return input(prompt)
    try:
        return getpass.getpass(prompt)
    except KeyboardInterrupt:
        print("\n(La saisie masquée ne marche pas dans ce terminal : le mot de passe sera VISIBLE quand vous le tapez.)")
        return input(prompt)


def ask_password(visible=False):
    while True:
        p1 = read_secret("Mot de passe (8 caractères minimum) : ", visible)
        if len(p1) < 8:
            print("  Trop court.")
            continue
        if p1 != read_secret("Confirmez le mot de passe : ", visible):
            print("  Les deux mots de passe sont différents.")
            continue
        return p1


def main():
    ap = argparse.ArgumentParser(description="Gestion des comptes TEMASA")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--unlock", metavar="NOM")
    ap.add_argument("--delete", metavar="NOM")
    ap.add_argument("--visible", action="store_true", help="afficher le mot de passe pendant la saisie (si la saisie masquée échoue)")
    a = ap.parse_args()
    cfg = ensure_structure(load())
    users = cfg["credentials"]["usernames"]

    if a.list:
        for n, u in users.items():
            print(f"{n:<15} {', '.join(u.get('roles', [])):<12} échecs : {u.get('failed_login_attempts', 0)}")
        return
    if a.unlock:
        n = a.unlock.lower().strip()
        if n not in users:
            sys.exit(f"Utilisateur inconnu : {n}")
        users[n]["failed_login_attempts"] = 0
        save(cfg)
        print(f"✅ {n} déverrouillé.")
        return
    if a.delete:
        n = a.delete.lower().strip()
        if users.pop(n, None) is None:
            sys.exit(f"Utilisateur inconnu : {n}")
        save(cfg)
        print(f"🗑️  {n} supprimé.")
        return

    username = input("Nom d'utilisateur (sans espaces) : ").lower().strip()
    if not username or " " in username:
        sys.exit("Nom d'utilisateur invalide.")
    first = input("Prénom : ").strip()
    last = input("Nom : ").strip()
    email = input("E-mail : ").strip()
    default_role = "admin" if not users else "utilisateur"
    role = (input(f"Rôle [admin / utilisateur] (défaut : {default_role}) : ").strip().lower() or default_role)
    if role not in ("admin", "utilisateur"):
        sys.exit("Rôle invalide : choisissez admin ou utilisateur.")
    if not users and role != "admin":
        print("⚠️  Aucun administrateur n'existe : ce premier compte est créé avec le rôle admin.")
        role = "admin"
    users[username] = {"email": email, "first_name": first, "last_name": last, "password": Hasher.hash(ask_password(a.visible)),
                       "roles": [role], "failed_login_attempts": 0, "logged_in": False}
    save(cfg)
    print(f"✅ Compte « {username} » ({role}) enregistré dans {CONFIG.name}.")


if __name__ == "__main__":
    main()
