"""
Accès à la base SQL Server (temasa_dw) : connexion, requêtes de l'assistant (protégées), chargement des données.

Configuration (administrateur uniquement, via .env ou .streamlit/secrets.toml) :
    DB_URL=...                      URL SQLAlchemy complète (prioritaire), ou bien :
    DB_SERVER=LAPTOP-AN5ESP2Q\\DS   DB_NAME=temasa_dw   DB_DRIVER=ODBC Driver 17 for SQL Server
    DB_USER / DB_PASSWORD           (vides = authentification Windows)
La chaîne de connexion et le mot de passe ne sont JAMAIS affichés dans l'interface.
"""
import urllib.parse

import pandas as pd
import streamlit as st
from sqlalchemy import create_engine, inspect

import settings
import sql_guard

SHIFTS = {1: "Matin", 2: "Après-midi", 3: "Nuit"}
REQUIRED_TABLES = ["dim_product", "dim_machine", "dim_client", "dim_defect_type",
                   "fact_production", "fact_quality", "fact_orders", "fact_stock"]


# ----------------------------------------------------------------------------- connexion
def build_url():
    url = settings.get("DB_URL")
    if url:
        return url
    server = settings.get("DB_SERVER")
    if not server:
        return None
    parts = [
        f"DRIVER={{{settings.get('DB_DRIVER', 'ODBC Driver 17 for SQL Server')}}}",
        f"SERVER={server}",
        f"DATABASE={settings.get('DB_NAME', 'temasa_dw')}",
    ]
    if settings.get("DB_USER"):
        parts += [f"UID={settings.get('DB_USER')}", f"PWD={settings.get('DB_PASSWORD', '')}"]
    else:
        parts.append("Trusted_Connection=yes")
    return "mssql+pyodbc:///?odbc_connect=" + urllib.parse.quote_plus(";".join(parts))


def is_configured() -> bool:
    return build_url() is not None


@st.cache_resource(show_spinner=False)
def get_engine():
    url = build_url()
    if not url:
        raise RuntimeError("Base de données non configurée.")
    kwargs = {"fast_executemany": True} if url.startswith("mssql") else {}
    return create_engine(url, pool_pre_ping=True, **kwargs)


def friendly_error(exc: Exception) -> str:
    """Message utilisateur sans chaîne de connexion ni mot de passe."""
    raw = settings.redact(str(getattr(exc, "orig", exc)))
    low = raw.lower()
    if "login failed" in low or "échec de l'ouverture de session" in low or "authentification" in low:
        hint = "Identifiants SQL refusés : vérifiez DB_USER / DB_PASSWORD (ou l'authentification Windows)."
    elif "timeout" in low or "délai" in low or "introuvable" in low or "not found" in low or "08001" in low:
        hint = "Serveur SQL introuvable ou arrêté : vérifiez DB_SERVER (ex. MACHINE\\INSTANCE) et que le service SQL Server est démarré."
    elif "driver" in low or "im002" in low:
        hint = "Pilote ODBC introuvable : installez « ODBC Driver 17 for SQL Server » ou changez DB_DRIVER."
    elif "cannot open database" in low or "impossible d'ouvrir la base" in low:
        hint = "Base de données introuvable : exécutez temasa_schema.sql puis clean_and_load.py."
    else:
        hint = "Erreur de base de données."
    return f"{hint}\n\nDétail technique : {raw[:300]}"


def test_connection():
    """(ok, message) pour la page Administration."""
    try:
        with get_engine().connect() as c:
            c.exec_driver_sql("SELECT 1").fetchone()
        return True, "Connexion à la base réussie."
    except Exception as e:
        return False, friendly_error(e)


def check_readonly_account():
    """True = le compte ne peut pas écrire (bien), False = il peut écrire (à corriger), None = inconnu."""
    url = build_url() or ""
    if not url.startswith("mssql"):
        return None
    try:
        with get_engine().connect() as c:
            rows = c.exec_driver_sql(
                "SELECT HAS_PERMS_BY_NAME('dbo.fact_orders','OBJECT','INSERT'), "
                "HAS_PERMS_BY_NAME('dbo.fact_orders','OBJECT','DELETE'), "
                "HAS_PERMS_BY_NAME('dbo.fact_orders','OBJECT','UPDATE')").fetchone()
        if rows is None or any(v is None for v in rows):
            return None
        return not any(int(v) == 1 for v in rows)
    except Exception:
        return None


@st.cache_data(ttl=600, show_spinner=False)
def get_schema() -> dict:
    """{table: [colonnes]} lu dans la base (mis en cache 10 min)."""
    insp = inspect(get_engine())
    names = set(insp.get_table_names()) | set(insp.get_view_names())
    return {t: [c["name"] for c in insp.get_columns(t)] for t in sorted(names)
            if t in sql_guard.ALLOWED_TABLES or t in REQUIRED_TABLES}


def missing_tables(required=REQUIRED_TABLES) -> list:
    try:
        have = set(get_schema())
    except Exception:
        return list(required)
    return [t for t in required if t not in have]


def schema_note() -> str:
    """Colonnes réelles de la base, ajoutées au prompt du modèle."""
    try:
        sch = get_schema()
    except Exception:
        return ""
    lines = [f"- {t}({', '.join(cols)})" for t, cols in sch.items()]
    return "\n\nCOLONNES RÉELLES DE LA BASE (référence prioritaire) :\n" + "\n".join(lines)


# ----------------------------------------------------------------------------- requêtes de l'assistant
def _tidy(df: pd.DataFrame) -> pd.DataFrame:
    """Decimal / texte numérique -> nombres, pour que les graphiques fonctionnent."""
    for c in df.columns:
        if df[c].dtype == object:
            conv = pd.to_numeric(df[c], errors="coerce")
            if conv.notna().sum() == df[c].notna().sum() and df[c].notna().any():
                df[c] = conv
    return df


def run_query(sql: str, max_rows: int = None, timeout: int = None):
    """Valide (sql_guard) puis exécute. Retourne (DataFrame, tronqué, sql_exécuté)."""
    max_rows = max_rows or settings.MAX_ROWS
    timeout = timeout or settings.QUERY_TIMEOUT
    engine = get_engine()
    dialect = {"mssql": "tsql", "postgresql": "postgres"}.get(engine.dialect.name, engine.dialect.name)
    safe = sql_guard.check_sql(sql, max_rows=max_rows, dialect=dialect)   # lève SQLGuardError
    with engine.connect() as conn:
        raw = conn.connection.driver_connection
        if hasattr(raw, "timeout"):                                # pyodbc : durée maximale d'une requête
            raw.timeout = timeout
        cur = conn.exec_driver_sql(safe)
        rows = cur.fetchmany(max_rows + 1)                         # 2e limite, côté client
        cols = list(cur.keys())
    truncated = len(rows) > max_rows
    df = pd.DataFrame([tuple(r) for r in rows[:max_rows]], columns=cols)
    return _tidy(df), truncated, safe


@st.cache_data(ttl=300, show_spinner=False)
def cached_query(sql: str):
    """Même chose que run_query, avec cache de 5 minutes (la même question ne rejoue pas le SQL)."""
    return run_query(sql)


# ----------------------------------------------------------------------------- données pour tableau de bord et ML
def _read(sql: str) -> pd.DataFrame:
    with get_engine().connect() as conn:
        cur = conn.exec_driver_sql(sql)
        df = pd.DataFrame([tuple(r) for r in cur.fetchall()], columns=list(cur.keys()))
    return _tidy(df)


def _to_date(key: pd.Series) -> pd.Series:
    return pd.to_datetime(key.astype("Int64").astype(str), format="%Y%m%d", errors="coerce")


@st.cache_data(ttl=600, show_spinner=False)
def load_production() -> pd.DataFrame:
    df = _read("""
        SELECT f.date_key, f.shift_key, f.qty_planned, f.qty_produced, f.qty_rejected, f.run_hours, f.downtime_hours,
               m.machine_code, m.department, p.product_code, p.category, p.target_group
        FROM fact_production f
        JOIN dim_machine m ON m.machine_key = f.machine_key
        JOIN dim_product p ON p.product_key = f.product_key""")
    df["date"] = _to_date(df["date_key"])
    df["shift_name"] = df["shift_key"].map(SHIFTS)
    for c in ["qty_planned", "qty_produced", "qty_rejected", "run_hours", "downtime_hours"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df.drop(columns=["date_key"]).sort_values("date").reset_index(drop=True)


@st.cache_data(ttl=600, show_spinner=False)
def load_quality() -> pd.DataFrame:
    df = _read("""
        SELECT q.date_key, q.qty_defective, d.defect_name, d.defect_family, m.machine_code, p.category
        FROM fact_quality q
        JOIN dim_defect_type d ON d.defect_type_key = q.defect_type_key
        LEFT JOIN dim_machine m ON m.machine_key = q.machine_key
        JOIN dim_product p ON p.product_key = q.product_key""")
    df["date"] = _to_date(df["date_key"])
    return df.drop(columns=["date_key"])


@st.cache_data(ttl=600, show_spinner=False)
def load_orders() -> pd.DataFrame:
    df = _read("""
        SELECT o.order_number, o.order_date_key, o.due_date_key, o.delivery_date_key, o.qty_ordered, o.qty_delivered,
               o.unit_price, c.client_name, c.country, c.segment, p.product_code, p.category
        FROM fact_orders o
        JOIN dim_client c ON c.client_key = o.client_key
        JOIN dim_product p ON p.product_key = o.product_key""")
    df["order_date"] = _to_date(df["order_date_key"])
    df["due_date"] = _to_date(df["due_date_key"])
    df["delivery_date"] = _to_date(df["delivery_date_key"])
    df["revenue"] = df["qty_delivered"] * df["unit_price"]
    return df.drop(columns=["order_date_key", "due_date_key", "delivery_date_key"])


@st.cache_data(ttl=600, show_spinner=False)
def load_stock() -> pd.DataFrame:
    df = _read("""
        SELECT s.date_key, s.qty_on_hand, s.min_stock_level, p.product_code, p.product_name, p.category
        FROM fact_stock s JOIN dim_product p ON p.product_key = s.product_key""")
    df["date"] = _to_date(df["date_key"])
    return df.drop(columns=["date_key"])
