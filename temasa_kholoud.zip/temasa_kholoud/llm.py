"""
Accès au modèle de langage - UN SEUL endroit pour changer de fournisseur.

Fournisseur choisi par l'administrateur avec LLM_PROVIDER dans .env ou .streamlit/secrets.toml :
    gemini     (par défaut, offre gratuite de Google AI Studio)
    anthropic  (API Claude, payante)

Aucune clé n'est écrite dans le code ni affichée dans l'interface.
Les appels passent par l'API REST (bibliothèque `requests`) : pas de SDK à installer.
"""
import json
import re

import requests

import settings

DEFAULT_MODELS = {"gemini": "gemini-3.5-flash", "anthropic": "claude-sonnet-5-5"}
GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta"
_resolved = {}          # modèle choisi automatiquement (Gemini), mémorisé pour la session du serveur
KEY_ENV = {"gemini": "GEMINI_API_KEY", "anthropic": "ANTHROPIC_API_KEY"}
TIMEOUT = 60


class LLMError(Exception):
    """Erreur de l'API : le message est en français et destiné à l'utilisateur (sans secret)."""

    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


# ----------------------------------------------------------------------------- configuration
def provider() -> str:
    p = (settings.get("LLM_PROVIDER", "gemini") or "gemini").lower()
    return p if p in KEY_ENV else "gemini"


def explicit_model():
    """Modèle imposé par l'administrateur (GEMINI_MODEL / ANTHROPIC_MODEL), sinon None."""
    return settings.get(f"{provider().upper()}_MODEL")


def model_name() -> str:
    return explicit_model() or _resolved.get(provider()) or DEFAULT_MODELS[provider()]


def clean_key(raw) -> str:
    """Retire espaces, retours à la ligne, guillemets et préfixe 'Bearer' collés par erreur."""
    if raw is None:
        return ""
    key = str(raw).strip().strip("\"'").strip()
    key = re.sub(r"^(bearer|x-api-key:|x-goog-api-key:)\s*", "", key, flags=re.I)
    return re.sub(r"\s+", "", key)


def get_key(prov: str = None) -> str:
    return clean_key(settings.get(KEY_ENV[prov or provider()]))


KEY_HELP = {
    "gemini": (
        "**Comment obtenir une clé Gemini gratuite :**\n"
        "1. Ouvrez https://aistudio.google.com/apikey et connectez-vous avec un compte Google.\n"
        "2. Cliquez sur « Create API key » puis copiez la clé (elle commence souvent par `AIza`).\n"
        "3. Dans le dossier de l'application, copiez `.env.example` en `.env` et écrivez :\n"
        "   `GEMINI_API_KEY=votre_clé` (sans guillemets ni espaces).\n"
        "4. Redémarrez l'application (`python -m streamlit run app.py`)."
    ),
    "anthropic": (
        "**Comment obtenir une clé Anthropic (payante) :**\n"
        "1. Ouvrez https://console.anthropic.com, créez un compte puis ajoutez du crédit (Billing).\n"
        "2. Menu « API keys » → « Create Key » et copiez la clé (elle commence par `sk-ant-`).\n"
        "3. Dans le fichier `.env` écrivez : `ANTHROPIC_API_KEY=sk-ant-...` (sans guillemets ni espaces).\n"
        "4. Redémarrez l'application. Pour une solution gratuite, choisissez `LLM_PROVIDER=gemini`."
    ),
}


def validate_key(prov: str = None, key: str = None):
    """Vérifie le format de la clé AVANT tout appel réseau. Retourne un message d'erreur ou None."""
    prov = prov or provider()
    key = get_key(prov) if key is None else clean_key(key)
    name = KEY_ENV[prov]
    if not key:
        return f"Aucune clé API : la variable {name} est vide ou absente."
    if key.lower() in {"votre_cle", "votre_clé", "your_key", "your_api_key", "xxx", "changeme", "..."} or "votre" in key.lower():
        return f"{name} contient encore la valeur d'exemple : remplacez-la par votre vraie clé."
    if prov == "anthropic" and not key.startswith("sk-ant-"):
        return "La clé Anthropic doit commencer par « sk-ant- » : vérifiez que vous avez copié la bonne clé."
    if prov == "gemini" and (len(key) < 20 or not re.fullmatch(r"[A-Za-z0-9_.\-]+", key)):   # anciennes clés « AIza… » et nouvelles « AQ.… »
        return "La clé Gemini semble invalide (caractères ou longueur inattendus) : recopiez-la depuis Google AI Studio."
    return None


def is_configured() -> bool:
    return validate_key() is None


def friendly_config_message() -> str:
    """Message complet (erreur + étapes) quand la clé manque ou est invalide."""
    prov = provider()
    err = validate_key(prov) or "La clé API est refusée par le fournisseur."
    return f"🔑 **{err}**\n\n{KEY_HELP[prov]}"


# ----------------------------------------------------------------------------- appel réseau
def _error_from_response(prov: str, r: requests.Response) -> LLMError:
    code = r.status_code
    try:
        body = r.json()
    except ValueError:
        body = {}
    detail = json.dumps(body)[:400].lower()
    if code in (401, 403) or "api key not valid" in detail or "api_key_invalid" in detail or "invalid x-api-key" in detail:
        return LLMError(friendly_config_message())
    if code == 404:
        return LLMError(f"Modèle introuvable : « {model_name()} » n'existe plus ou n'est pas disponible pour cette clé. "
                        f"Utilisez Administration → « Lister les modèles » puis écrivez {prov.upper()}_MODEL=... dans .env.", status=404)
    if code == 429:
        return LLMError("Limite d'utilisation atteinte (quota gratuit ou trop de requêtes). Attendez une minute puis réessayez. "
                        "Si le message revient toujours, essayez un autre modèle (Administration → Lister les modèles).", status=429)
    if code in (500, 502, 503, 504, 529):
        return LLMError("Le service du modèle est momentanément indisponible. Réessayez dans quelques instants.")
    if code == 400:
        return LLMError("La requête a été refusée par le fournisseur (400). Reformulez votre question ou vérifiez le nom du modèle.")
    return LLMError(f"Erreur du fournisseur de modèle (code {code}).")


def _post(prov: str, url: str, headers: dict, payload: dict) -> dict:
    try:
        r = requests.post(url, headers=headers, json=payload, timeout=TIMEOUT)
    except requests.exceptions.Timeout:
        raise LLMError("Le modèle n'a pas répondu à temps. Réessayez.")
    except requests.exceptions.RequestException:
        raise LLMError("Impossible de joindre le service du modèle : vérifiez la connexion Internet.")
    if r.status_code != 200:
        raise _error_from_response(prov, r)
    try:
        return r.json()
    except ValueError:
        raise LLMError("Réponse illisible du fournisseur de modèle.")


def list_gemini_models() -> list:
    """Noms des modèles Gemini que CETTE clé peut utiliser pour générer du texte."""
    err = validate_key("gemini")
    if err:
        raise LLMError(friendly_config_message())
    try:
        r = requests.get(f"{GEMINI_BASE}/models?pageSize=200", headers={"x-goog-api-key": get_key("gemini")}, timeout=30)
    except requests.exceptions.RequestException:
        raise LLMError("Impossible de joindre Google : vérifiez la connexion Internet.")
    if r.status_code != 200:
        raise _error_from_response("gemini", r)
    return [m["name"].split("/", 1)[-1] for m in r.json().get("models", [])
            if "generateContent" in m.get("supportedGenerationMethods", [])]


_EXCLUDED = ("image", "live", "audio", "tts", "embedding", "robotics", "computer", "customtools", "exp", "thinking")


def rank_gemini_models(names: list) -> list:
    """Meilleurs candidats d'abord : « flash » stable le plus récent, puis lite, puis preview."""
    scored = []
    for n in names:
        m = re.fullmatch(r"gemini-(\d+(?:\.\d+)*)-flash(.*)", n)
        if not m or any(x in n for x in _EXCLUDED):
            continue
        version, suffix = tuple(int(x) for x in m.group(1).split(".")), m.group(2)
        tier = 2 if "preview" in suffix else 1 if "lite" in suffix else 0
        scored.append((tier, tuple(-v for v in version), n))
    return [n for _, _, n in sorted(scored)]


def _gemini_candidates() -> list:
    if explicit_model():
        return [explicit_model()]
    if _resolved.get("gemini"):
        return [_resolved["gemini"]]
    try:
        ranked = rank_gemini_models(list_gemini_models())[:4]
    except LLMError:
        ranked = []
    return ranked or [DEFAULT_MODELS["gemini"]]


def complete(system: str, messages: list, max_tokens: int = 1200, json_mode: bool = False) -> str:
    """
    messages : [{"role": "user" | "assistant", "content": "..."}] (alternés, le dernier est "user").
    Retourne le texte de la réponse ou lève LLMError.
    """
    prov = provider()
    err = validate_key(prov)
    if err:
        raise LLMError(friendly_config_message())
    key = get_key(prov)

    if prov == "anthropic":
        data = _post(prov, "https://api.anthropic.com/v1/messages",
                     {"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                     {"model": model_name(), "max_tokens": max_tokens, "system": system, "messages": messages})
        text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    else:
        contents = [{"role": "model" if m["role"] == "assistant" else "user", "parts": [{"text": m["content"]}]}
                    for m in messages]
        gen_cfg = {"maxOutputTokens": max(max_tokens, 2048), "temperature": 0}
        if json_mode:
            gen_cfg["responseMimeType"] = "application/json"
        body = {"systemInstruction": {"parts": [{"text": system}]}, "contents": contents, "generationConfig": gen_cfg}
        tried, data, explicit = [], None, explicit_model()
        for model in _gemini_candidates():              # un modèle retiré par Google (404) -> on essaie le suivant
            try:
                data = _post(prov, f"{GEMINI_BASE}/models/{model}:generateContent",
                             {"x-goog-api-key": key, "content-type": "application/json"}, body)
                if not explicit:
                    _resolved["gemini"] = model          # on garde le modèle qui marche
                break
            except LLMError as e:
                tried.append(model)
                if e.status != 404 or explicit:
                    raise
                _resolved.pop("gemini", None)
        if data is None:
            _resolved.pop("gemini", None)
            raise LLMError("Aucun modèle Gemini disponible pour cette clé (essayés : " + ", ".join(tried) + "). "
                           "Utilisez Administration → « Lister les modèles » puis écrivez GEMINI_MODEL=... dans .env.", status=404)
        cands = data.get("candidates") or []
        if not cands:
            raise LLMError("Le modèle n'a pas produit de réponse (contenu bloqué ?). Reformulez la question.")
        text = "".join(p.get("text", "") for p in cands[0].get("content", {}).get("parts", []))
    if not text.strip():
        raise LLMError("Le modèle a renvoyé une réponse vide. Réessayez.")
    return text.strip()


# ----------------------------------------------------------------------------- prompts
SCHEMA_PROMPT = """
Tu es l'assistant de données de TEMASA (Tétouan Maille), fabricant marocain de chaussettes (Chaussettes) et de collants
(Collants). Tu réponds aux questions des responsables en écrivant UNE seule requête SQL en LECTURE SEULE pour
Microsoft SQL Server (T-SQL) sur la base temasa_dw.

PÉRIODE DES DONNÉES : du 2025-01-01 au 2026-09-30 (les données s'arrêtent à cette date, ce n'est pas du temps réel).
Interprète « le mois dernier », « cette année » par rapport à la DERNIÈRE date des données, jamais GETDATE().
Monnaie : MAD. Les équipes font 8 h, du lundi au samedi.

TABLES (schéma en étoile). Les colonnes *_key sont des clés entières ; les clés de date sont des entiers aaaammjj.
dim_date(date_key, full_date, year, quarter, month, month_name, week_of_year, day_of_week, day_name, is_weekend)
dim_product(product_key, product_code, product_name, category['Chaussettes'|'Collants'],
            target_group['Homme'|'Femme'|'Enfant'], size, color, quality_grade['Premium'|'Standard'|'Eco'], unit_cost)
dim_machine(machine_key, machine_code 'MC-01'..'MC-12', machine_type, department['Tricotage'|'Confection'], capacity_per_shift)
dim_client(client_key, client_code, client_name, country, segment['Export'|'Local'])
dim_shift(shift_key 1..3, shift_name['Matin'|'Après-midi'|'Nuit'])
dim_defect_type(defect_type_key, defect_name, defect_family['Tricotage'|'Confection'|'Finition'])
fact_production(production_id, date_key, product_key, machine_key, shift_key, qty_planned (peut être NULL),
                qty_produced, qty_rejected, run_hours, downtime_hours)        -- 1 ligne = 1 machine x 1 équipe
fact_quality(quality_id, date_key, product_key, machine_key, defect_type_key, qty_defective)
fact_orders(order_line_id, order_number, order_date_key, due_date_key, delivery_date_key (NULL = pas encore livré),
            client_key, product_key, qty_ordered, qty_delivered, unit_price)  -- 1 ligne = 1 ligne de commande
fact_stock(stock_id, date_key, product_key, qty_on_hand, min_stock_level)     -- instantanés de fin de mois
VUES : vw_production(production_id, full_date, year, month, month_name, product_code, category, target_group,
       machine_code, department, shift_name, qty_planned, qty_produced, qty_rejected, run_hours, downtime_hours)
       vw_orders(order_line_id, order_number, order_date, due_date, delivery_date, client_name, country, segment,
       product_code, category, qty_ordered, qty_delivered, unit_price, revenue)

DÉFINITIONS DES INDICATEURS :
- Taux de rebut % = 100.0 * SUM(qty_rejected) / SUM(qty_produced)
- Atteinte du plan % = 100.0 * SUM(qty_produced) / SUM(qty_planned)  (ignorer les NULL)
- Taux d'utilisation machine % = 100.0 * SUM(run_hours) / (SUM(run_hours) + SUM(downtime_hours))
- Chiffre d'affaires = SUM(qty_delivered * unit_price)
- Livraison à temps % = part des lignes livrées (delivery_date_key IS NOT NULL) avec delivery_date_key <= due_date_key
- Taux de service % = 100.0 * SUM(qty_delivered) / SUM(qty_ordered) sur les lignes livrées
- Stock critique = qty_on_hand < min_stock_level au dernier instantané (MAX(date_key) de fact_stock)
- Les quantités sont en paires (chaussettes) ou en pièces (collants).

RÈGLES :
- T-SQL : utilise TOP (n), jamais LIMIT. Utilise CAST(... AS DECIMAL(10,2)) et 100.0 * ... pour éviter la division entière.
- SELECT uniquement (ou WITH ... SELECT). Une seule requête, sans commentaire, sans point-virgule au milieu.
- Maximum TOP (200) lignes sauf demande contraire. Donne des alias de colonnes lisibles.
- N'utilise QUE les tables et colonnes ci-dessus. Si la question est hors sujet, ambiguë ou impossible avec ces
  données, n'invente rien : réponds avec "sql": null et une réponse courte (question de précision ou explication).
- Pas de prévision ni de faits extérieurs à la base.

SORTIE : réponds UNIQUEMENT avec un objet JSON, sans balises markdown :
{"sql": "<la requête ou null>", "reply": "<seulement si sql est null : ta courte réponse, dans la langue de l'utilisateur>"}
"""

ANSWER_PROMPT = """Tu es l'assistant de données de TEMASA. Rédige une réponse courte et claire (2 à 5 phrases) à la question
du responsable en utilisant UNIQUEMENT le résultat de requête fourni. Cite les chiffres clés avec séparateurs de milliers et
unités (paires/pièces, MAD, %). Réponds dans la même langue que la question. Si le résultat est vide, dis qu'aucune donnée
ne correspond. Si le résultat est tronqué, précise qu'il ne montre que les premières lignes. Ne parle ni de SQL ni de technique."""


def parse_llm_json(text: str) -> dict:
    t = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    try:
        return json.loads(t)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", t, re.S)
        if m:
            return json.loads(m.group(0))
        raise LLMError("Le modèle a répondu dans un format inattendu. Reformulez la question.")


def generate_sql(question: str, history=None, error: str = None, previous_sql: str = None,
                 schema_note: str = "") -> dict:
    """Retourne {"sql": str|None, "reply": str|None}."""
    messages = []
    for q, s in (history or [])[-3:]:                      # 3 derniers échanges pour les questions de suivi
        messages.append({"role": "user", "content": q})
        messages.append({"role": "assistant", "content": json.dumps({"sql": s})})
    messages.append({"role": "user", "content": question})
    if error:
        messages.append({"role": "assistant", "content": json.dumps({"sql": previous_sql})})
        messages.append({"role": "user", "content":
                         f"Cette requête a échoué avec l'erreur SQL Server suivante :\n{error}\nCorrige-la et renvoie le JSON."})
    return parse_llm_json(complete(SCHEMA_PROMPT + schema_note, messages, json_mode=True))


def explain_result(question: str, df, truncated: bool) -> str:
    sample = df.head(50).to_csv(index=False)
    note = f"\n(Résultat : {len(df)} lignes{', tronqué' if truncated else ''} ; 50 premières lignes montrées.)"
    return complete(ANSWER_PROMPT, [{"role": "user", "content": f"Question : {question}\n\nRésultat (CSV) :\n{sample}{note}"}],
                    max_tokens=600)
