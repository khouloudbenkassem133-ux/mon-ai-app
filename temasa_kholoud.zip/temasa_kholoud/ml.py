"""
Régression et Machine Learning sur les données TEMASA (100 % local : scikit-learn + statsmodels, aucun coût).

Méthode commune :
  - découpage TEMPOREL (on entraîne sur le passé, on teste sur la période la plus récente : pas de fuite de données) ;
  - validation croisée à fenêtre croissante (TimeSeriesSplit) ;
  - métriques sur la période de test, comparées à une référence simple ;
  - avertissements clairs quand il y a trop peu de données. Rien n'est inventé : si une colonne manque, on le dit.
"""
import warnings
from datetime import datetime
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import (GradientBoostingRegressor, IsolationForest, RandomForestClassifier,
                              RandomForestRegressor)
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, mean_absolute_error, mean_squared_error,
                             precision_score, r2_score, recall_score, roc_auc_score, roc_curve)
from sklearn.model_selection import TimeSeriesSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

import settings

warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

TASKS = {
    "forecast": "Prévision de production",
    "scrap_drivers": "Facteurs du taux de rebut (régression)",
    "classif_scrap": "Classification : rebut élevé",
    "classif_late": "Classification : livraison en retard",
    "anomalies": "Détection d'anomalies",
}
TARGETS = {"Production (quantité)": "production", "Rebut (quantité)": "rebut", "Taux de rebut (%)": "taux_rebut"}
SEED = 0


class MLDataError(Exception):
    """Données insuffisantes ou manquantes (message en français pour l'utilisateur)."""


# ----------------------------------------------------------------------------- sauvegarde des modèles
def _path(task: str) -> Path:
    settings.MODELS_DIR.mkdir(parents=True, exist_ok=True)
    return settings.MODELS_DIR / f"{task}.joblib"


def save_bundle(task: str, results: dict, model, params: dict, user: str = ""):
    bundle = {"task": task, "results": results, "model": model, "params": params, "trained_by": user,
              "trained_at": datetime.now().strftime("%Y-%m-%d %H:%M")}
    joblib.dump(bundle, _path(task))
    return bundle


def load_bundle(task: str):
    p = _path(task)
    if not p.exists():
        return None
    try:
        return joblib.load(p)       # fichier produit par l'application elle-même (dossier models/)
    except Exception:
        return None


def list_bundles() -> pd.DataFrame:
    rows = []
    for t, label in TASKS.items():
        b = load_bundle(t)
        rows.append({"Modèle": label, "Entraîné le": b["trained_at"] if b else "—",
                     "Par": b.get("trained_by", "") if b else "", "Fichier": f"{t}.joblib"})
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------- outils communs
def _need(df: pd.DataFrame, cols, table: str):
    miss = [c for c in cols if c not in df.columns]
    if miss:
        raise MLDataError(f"Colonne(s) manquante(s) dans {table} : {', '.join(miss)}. Rien n'a été inventé : corrigez la base.")


def _filter(prod: pd.DataFrame, start, end, machines=None) -> pd.DataFrame:
    df = prod[(prod["date"] >= pd.Timestamp(start)) & (prod["date"] <= pd.Timestamp(end))]
    if machines:
        df = df[df["machine_code"].isin(machines)]
    return df.copy()


def _split_by_date(df: pd.DataFrame, date_col: str, test_frac: float = 0.2):
    """Passé -> entraînement, période la plus récente -> test (aucune ligne du test avant le train)."""
    df = df.sort_values(date_col).reset_index(drop=True)
    cutoff = df[date_col].quantile(1 - test_frac)
    train, test = df[df[date_col] < cutoff], df[df[date_col] >= cutoff]
    return train, test, cutoff


def _fmt_p(p: float) -> str:
    return "p < 0,001" if p < 0.001 else f"p = {p:.3f}".replace(".", ",")


def _rmse(y, p):
    return float(np.sqrt(mean_squared_error(y, p)))


# ----------------------------------------------------------------------------- 1a. Prévision de production
def build_series(prod, target, freq, start, end, machines=None) -> pd.Series:
    _need(prod, ["date", "qty_produced", "qty_rejected", "machine_code"], "fact_production")
    df = _filter(prod, start, end, machines)
    if df.empty:
        raise MLDataError("Aucune donnée de production sur cette période.")
    per = (df["date"].dt.to_period("W-SUN") if freq == "W" else df["date"].dt.to_period("M")).dt.start_time
    g = df.groupby(per).agg(produced=("qty_produced", "sum"), rejected=("qty_rejected", "sum"))
    if target == "production":
        s = g["produced"]
    elif target == "rebut":
        s = g["rejected"]
    else:
        s = 100.0 * g["rejected"] / g["produced"].replace(0, np.nan)
    s = s.astype(float).dropna()
    # on retire les périodes de début / fin incomplètes
    first, last = s.index[0], s.index[-1]
    if df["date"].min() > first:
        s = s.iloc[1:]
    if len(s) and ((freq == "W" and df["date"].max() < last + pd.Timedelta(days=5)) or
                   (freq == "M" and df["date"].max() < last + pd.offsets.MonthEnd(0) - pd.Timedelta(days=2))):
        s = s.iloc[:-1]
    s.index.name = "periode"
    return s


def _design(periods, origin, freq) -> pd.DataFrame:
    periods = pd.DatetimeIndex(periods)
    if freq == "W":
        t = (periods - origin).days / 7.0
        angle = 2 * np.pi * periods.dayofyear / 365.25
    else:
        t = (periods.year - origin.year) * 12 + (periods.month - origin.month)
        angle = 2 * np.pi * periods.month / 12.0
    return pd.DataFrame({"tendance": np.asarray(t, float), "saison_sin": np.sin(angle), "saison_cos": np.cos(angle)})


def _fit_predict(name, Xtr, ytr, Xte):
    if name == "Régression linéaire":
        res = sm.OLS(ytr.values, sm.add_constant(Xtr, has_constant="add")).fit()
        return res.predict(sm.add_constant(Xte, has_constant="add"))
    if name == "Moyenne (référence)":
        return np.full(len(Xte), float(ytr.mean()))
    est = (RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=SEED) if name == "Random Forest"
           else GradientBoostingRegressor(random_state=SEED))
    return est.fit(Xtr, ytr).predict(Xte)


def train_forecast(prod, target="production", freq="W", start=None, end=None, machines=None, horizon=8):
    s = build_series(prod, target, freq, start, end, machines)
    n = len(s)
    min_n, two_seasons = (26, 104) if freq == "W" else (12, 24)
    unit = "semaines" if freq == "W" else "mois"
    if n < min_n:
        raise MLDataError(f"Seulement {n} {unit} de données : il en faut au moins {min_n} pour une prévision fiable. "
                          "Élargissez la période ou passez à une granularité plus fine.")
    warns = []
    if n < two_seasons:
        warns.append(f"Seulement {n} {unit} (moins de deux années complètes) : la saisonnalité annuelle ne peut pas être "
                     "validée, la prévision reste indicative.")
    origin = s.index[0]
    X = _design(s.index, origin, freq)
    test_n = max(4, int(round(0.2 * n)))
    Xtr, Xte, ytr, yte = X.iloc[:-test_n], X.iloc[-test_n:], s.iloc[:-test_n], s.iloc[-test_n:]

    names = ["Régression linéaire", "Random Forest", "Gradient Boosting", "Moyenne (référence)"]
    rows, test_pred, cv_rmse = [], pd.DataFrame({"periode": yte.index, "reel": yte.values}), {}
    for nm in names:
        p = np.asarray(_fit_predict(nm, Xtr, ytr, Xte), float)
        test_pred[nm] = p
        # validation croisée à fenêtre croissante sur la partie entraînement
        maes, rmses = [], []
        if len(Xtr) >= 16:
            tss = TimeSeriesSplit(n_splits=3, test_size=max(2, len(Xtr) // 8))
            for a, b in tss.split(Xtr):
                pp = np.asarray(_fit_predict(nm, Xtr.iloc[a], ytr.iloc[a], Xtr.iloc[b]), float)
                maes.append(mean_absolute_error(ytr.iloc[b], pp))
                rmses.append(_rmse(ytr.iloc[b], pp))
        cv_rmse[nm] = float(np.mean(rmses)) if rmses else _rmse(yte, p)
        rows.append({"Modèle": nm, "MAE": mean_absolute_error(yte, p), "RMSE": _rmse(yte, p), "R²": r2_score(yte, p),
                     "MAE (validation croisée)": float(np.mean(maes)) if maes else np.nan})
    metrics = pd.DataFrame(rows)
    best = metrics[metrics["Modèle"] != "Moyenne (référence)"].sort_values("MAE").iloc[0]["Modèle"]

    # prévisions futures : chaque modèle est ré-entraîné sur TOUTES les périodes
    step = pd.Timedelta(weeks=1) if freq == "W" else None
    future = pd.DatetimeIndex([s.index[-1] + (step * k if freq == "W" else pd.DateOffset(months=k))
                               for k in range(1, horizon + 1)])
    Xf = _design(future, origin, freq)
    forecasts, ols_summary = {}, {}
    for nm in names[:3]:
        if nm == "Régression linéaire":
            res = sm.OLS(s.values, sm.add_constant(X, has_constant="add")).fit()
            fr = res.get_prediction(sm.add_constant(Xf, has_constant="add")).summary_frame(alpha=0.05)
            pred, lo, hi = fr["mean"].values, fr["obs_ci_lower"].values, fr["obs_ci_upper"].values
            ols_summary = {"pente": float(res.params["tendance"]), "p_pente": float(res.pvalues["tendance"]),
                           "amplitude_saison": float(np.hypot(res.params["saison_sin"], res.params["saison_cos"])),
                           "r2": float(res.rsquared)}
        else:
            pred = np.asarray(_fit_predict(nm, X, s, Xf), float)
            lo, hi = pred - 1.96 * cv_rmse[nm], pred + 1.96 * cv_rmse[nm]        # bande approximative
        if target != "taux_rebut":
            lo = np.maximum(lo, 0)
        forecasts[nm] = pd.DataFrame({"periode": future, "prevision": pred, "bas": lo, "haut": hi})

    best_row, base_row = metrics.set_index("Modèle").loc[best], metrics.set_index("Modèle").loc["Moyenne (référence)"]
    gain = 100 * (1 - best_row["MAE"] / base_row["MAE"]) if base_row["MAE"] else 0
    interp = [f"Le meilleur modèle sur la période de test ({test_n} {unit} les plus récentes) est **{best}** "
              f"(erreur moyenne MAE = {best_row['MAE']:,.1f}, R² = {best_row['R²']:.2f})."]
    interp.append(f"Il fait {'mieux' if gain > 0 else 'moins bien'} que la simple moyenne historique "
                  f"({abs(gain):.0f} % d'erreur en {'moins' if gain > 0 else 'plus'}).")
    if ols_summary:
        sig = "significative" if ols_summary["p_pente"] < 0.05 else "non significative (indistinguable du bruit)"
        sens = "hausse" if ols_summary["pente"] > 0 else "baisse"
        interp.append(f"Tendance : {sens} de {abs(ols_summary['pente']):,.1f} par {'semaine' if freq == 'W' else 'mois'}, {sig} "
                      f"({_fmt_p(ols_summary['p_pente'])}).")
    if best_row["MAE (validation croisée)"] > base_row["MAE (validation croisée)"] * 1.05:
        warns.append(f"Résultat instable : en validation croisée sur le passé, {best} se trompe plus que la simple moyenne "
                     f"(MAE {best_row['MAE (validation croisée)']:,.0f} contre {base_row['MAE (validation croisée)']:,.0f}). "
                     "Sa bonne note sur la période de test peut venir du hasard ; prudence avec les prévisions.")
    if best_row["R²"] < 0:
        warns.append("R² négatif sur le test : le modèle prédit moins bien qu'une moyenne constante. Ne pas s'y fier.")
    ser = s.reset_index()
    ser.columns = ["periode", "valeur"]
    results = {"series": ser,
               "metrics": metrics, "test_pred": test_pred, "forecasts": forecasts, "best": best, "warnings": warns,
               "interpretation": interp, "ols": ols_summary, "target": target, "freq": freq, "n_periods": n, "test_n": test_n}
    return results, {"best": best}


# ----------------------------------------------------------------------------- 1b. Facteurs du taux de rebut (régression)
VAR_LABELS = {"machine_code": "Machine", "shift_name": "Équipe", "category": "Catégorie de produit",
              "target_group": "Public", "downtime_hours": "Heures d'arrêt"}


def _ref(df, col):
    if col == "machine_code":                      # machine « médiane » en taux de rebut
        m = (100.0 * df.groupby(col)["qty_rejected"].sum() / df.groupby(col)["qty_produced"].sum()).sort_values()
        return m.index[len(m) // 2]
    return df[col].value_counts().idxmax()


def train_scrap_drivers(prod, start, end, machines=None):
    _need(prod, ["date", "qty_produced", "qty_rejected", "machine_code", "shift_name", "category", "target_group",
                 "downtime_hours"], "fact_production")
    df = _filter(prod, start, end, machines)
    df = df[df["qty_produced"] > 0].dropna(subset=["shift_name", "downtime_hours"]).copy()
    if len(df) < 300:
        raise MLDataError(f"Seulement {len(df)} lignes de production : il en faut au moins 300 pour une régression fiable.")
    df["taux_rebut"] = 100.0 * df["qty_rejected"] / df["qty_produced"]
    warns = []
    cats = [c for c in ["machine_code", "shift_name", "category", "target_group"] if df[c].nunique() > 1]
    for c in set(["machine_code", "shift_name", "category", "target_group"]) - set(cats):
        warns.append(f"La variable « {VAR_LABELS[c]} » est constante sur la période : elle est ignorée.")
    refs = {c: _ref(df, c) for c in cats}
    terms = [f"C({c}, Treatment(reference='{refs[c]}'))" for c in cats]
    if df["downtime_hours"].std() > 0:
        terms.append("downtime_hours")
    else:
        warns.append("Les heures d'arrêt sont constantes sur la période : variable ignorée.")
    if not terms:
        raise MLDataError("Aucune variable explicative ne varie sur cette période : régression impossible.")
    formula = "taux_rebut ~ " + " + ".join(terms)
    full = smf.ols(formula, data=df).fit(cov_type="HC3")               # écarts-types robustes
    ci = full.conf_int()
    rows = []
    for term, coef in full.params.items():
        if term == "Intercept":
            continue
        if "[T." in term:
            var = term.split("(")[1].split(",")[0]
            level = term.split("[T.")[1].rstrip("]")
            label, ref = f"{VAR_LABELS[var]} = {level}", refs[var]
            comparaison = f"par rapport à {ref}" + (" (machine médiane)" if var == "machine_code" else "")
        else:
            label, comparaison = VAR_LABELS.get(term, term), "par heure supplémentaire"
        rows.append({"Variable": label, "Référence": comparaison, "Coefficient (points de %)": coef,
                     "Erreur-type": full.bse[term], "p-value": full.pvalues[term],
                     "IC 95 % bas": ci.loc[term, 0], "IC 95 % haut": ci.loc[term, 1]})
    coefs = pd.DataFrame(rows)
    coefs["_sig"], coefs["_abs"] = coefs["p-value"] < 0.05, coefs["Coefficient (points de %)"].abs()
    coefs = coefs.sort_values(["_sig", "_abs"], ascending=[False, False]).drop(columns=["_sig", "_abs"]).reset_index(drop=True)

    # validation sur la période la plus récente (modèle estimé sur le passé seulement)
    train, test, cutoff = _split_by_date(df, "date")
    hold = {"r2": np.nan, "mae": np.nan, "rmse": np.nan}
    try:
        m_tr = smf.ols(formula, data=train).fit()
        p = m_tr.predict(test)
        hold = {"r2": float(r2_score(test["taux_rebut"], p)), "mae": float(mean_absolute_error(test["taux_rebut"], p)),
                "rmse": _rmse(test["taux_rebut"], p)}
    except Exception:
        pass
    if abs(df["taux_rebut"].std()) == 0:
        warns.append("Le taux de rebut ne varie pas : régression impossible.")
    sig = coefs[coefs["p-value"] < 0.05].copy()
    sig["abs"] = sig["Coefficient (points de %)"].abs()
    interp = [f"Le modèle explique **{full.rsquared * 100:.0f} %** de la variabilité du taux de rebut par ligne de production "
              f"(R² = {full.rsquared:.2f}, R² ajusté = {full.rsquared_adj:.2f} ; sur la période récente non vue : R² = "
              f"{hold['r2']:.2f})."]
    for _, r in sig.sort_values("abs", ascending=False).head(6).iterrows():
        sens = "augmente" if r["Coefficient (points de %)"] > 0 else "diminue"
        interp.append(f"**{r['Variable']}**, {r['Référence']}, {sens} le taux de rebut de "
                      f"**{abs(r['Coefficient (points de %)']):.2f} point(s)**, effet significatif ({_fmt_p(r['p-value'])}).")
    ns = coefs[coefs["p-value"] >= 0.05]
    if len(ns):
        interp.append("Sans effet démontré (p ≥ 0,05) : " + ", ".join(ns["Variable"].head(6)) + ".")
    interp.append("Attention : ces coefficients décrivent des associations observées, pas des causes prouvées.")
    results = {"coefs": coefs, "r2": float(full.rsquared), "r2_adj": float(full.rsquared_adj), "n": int(full.nobs),
               "f_pvalue": float(full.f_pvalue), "holdout": hold, "refs": refs, "interpretation": interp, "warnings": warns,
               "mean_rate": float(df["taux_rebut"].mean()),
               "residuals": pd.DataFrame({"ajuste": full.fittedvalues.sample(min(2000, len(df)), random_state=SEED),
                                          "residu": full.resid.sample(min(2000, len(df)), random_state=SEED)})}
    full.remove_data()
    return results, full


# ----------------------------------------------------------------------------- 2a. Classification
def _pipeline(kind, cat_cols, num_cols):
    pre = ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
        ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), num_cols),
    ])
    clf = (LogisticRegression(max_iter=2000, class_weight="balanced") if kind == "Régression logistique"
           else RandomForestClassifier(n_estimators=300, min_samples_leaf=3, class_weight="balanced_subsample",
                                       random_state=SEED, n_jobs=-1))
    return Pipeline([("pre", pre), ("clf", clf)])


def _classify(df, date_col, cat_cols, num_cols, target_col, pos_label, min_rows=300):
    df = df.sort_values(date_col).reset_index(drop=True)
    if len(df) < min_rows:
        raise MLDataError(f"Seulement {len(df)} lignes exploitables : il en faut au moins {min_rows} pour un classifieur fiable.")
    train, test, cutoff = _split_by_date(df, date_col)
    feats = cat_cols + num_cols
    ytr, yte = train[target_col].astype(int), test[target_col].astype(int)
    warns = []
    if ytr.nunique() < 2:
        raise MLDataError("Une seule classe dans les données d'entraînement : impossible d'apprendre à distinguer les cas.")
    if ytr.sum() < 30:
        warns.append(f"Seulement {int(ytr.sum())} cas « {pos_label} » dans l'entraînement : résultats peu fiables.")
    if yte.nunique() < 2:
        warns.append("Une seule classe dans la période de test : ROC-AUC non calculable.")
    elif yte.sum() < 10:
        warns.append(f"Seulement {int(yte.sum())} cas « {pos_label} » dans la période de test : métriques instables.")
    out, fitted, preds = {}, {}, test[[date_col]].copy()
    preds["reel"] = yte.values
    for kind in ["Régression logistique", "Random Forest"]:
        pipe = _pipeline(kind, cat_cols, num_cols).fit(train[feats], ytr)
        proba = pipe.predict_proba(test[feats])[:, 1]
        pred = (proba >= 0.5).astype(int)
        two = yte.nunique() == 2
        auc = float(roc_auc_score(yte, proba)) if two else np.nan
        fpr, tpr, _ = roc_curve(yte, proba) if two else (np.array([0, 1]), np.array([0, 1]), None)
        cv_auc = []
        for a, b in TimeSeriesSplit(n_splits=4).split(train):
            ya, yb = ytr.iloc[a], ytr.iloc[b]
            if ya.nunique() < 2 or yb.nunique() < 2:
                continue
            p2 = _pipeline(kind, cat_cols, num_cols).fit(train.iloc[a][feats], ya)
            cv_auc.append(roc_auc_score(yb, p2.predict_proba(train.iloc[b][feats])[:, 1]))
        imp = permutation_importance(pipe, test[feats], yte, scoring="roc_auc" if two else "accuracy",
                                     n_repeats=5, random_state=SEED)
        out[kind] = {
            "accuracy": float(accuracy_score(yte, pred)), "precision": float(precision_score(yte, pred, zero_division=0)),
            "recall": float(recall_score(yte, pred, zero_division=0)), "f1": float(f1_score(yte, pred, zero_division=0)),
            "auc": auc, "cv_auc": float(np.mean(cv_auc)) if cv_auc else np.nan,
            "confusion": confusion_matrix(yte, pred, labels=[0, 1]).tolist(), "roc": {"fpr": fpr.tolist(), "tpr": tpr.tolist()},
            "importance": pd.DataFrame({"Variable": feats, "Importance": imp.importances_mean}).sort_values("Importance", ascending=False),
        }
        preds[f"proba_{kind}"] = proba
        fitted[kind] = _pipeline(kind, cat_cols, num_cols).fit(df[feats], df[target_col].astype(int))   # modèle final (tout l'historique)
    base_acc = float(max(yte.mean(), 1 - yte.mean()))
    info = {"n_train": len(train), "n_test": len(test), "cutoff": str(pd.Timestamp(cutoff).date()),
            "pos_rate_train": float(ytr.mean()), "pos_rate_test": float(yte.mean()), "baseline_accuracy": base_acc}
    return out, fitted, preds.join(test[feats].reset_index(drop=True).set_axis(preds.index)), info, warns


def _interpret_classif(res, info, pos_label, top_n=3):
    lines = [f"Période de test : à partir du {info['cutoff']} ({info['n_test']} cas, {info['pos_rate_test'] * 100:.0f} % de « {pos_label} »). "
             f"Une réponse « jamais {pos_label} » donnerait {info['baseline_accuracy'] * 100:.0f} % de bonnes réponses : c'est la référence à battre."]
    for kind, r in res.items():
        a = r["auc"]
        if np.isnan(a):
            verdict = "non évaluable"
        elif a >= 0.9:
            verdict = "excellent"
        elif a >= 0.75:
            verdict = "bon"
        elif a >= 0.6:
            verdict = "moyen"
        else:
            verdict = "aucun pouvoir prédictif démontré (proche du hasard = 0,5)"
        lines.append(f"**{kind}** : ROC-AUC = {a:.2f} → {verdict} ; rappel = {r['recall'] * 100:.0f} %, précision = {r['precision'] * 100:.0f} %.")
    best = max(res, key=lambda k: (np.nan_to_num(res[k]["auc"], nan=0)))
    top = res[best]["importance"].head(top_n)
    lines.append("Variables les plus utiles (" + best + ") : " + ", ".join(f"{v} ({i:.3f})" for v, i in zip(top["Variable"], top["Importance"])) + ".")
    if np.nan_to_num(res[best]["auc"], nan=0) >= 0.97:
        lines.append(f"ℹ️ Un ROC-AUC quasi parfait signifie qu'une seule variable domine (ici « {top['Variable'].iloc[0]} ») : "
                     "le modèle confirme surtout ce que l'analyse de régression montre déjà. Vérifiez aussi qu'aucune variable "
                     "ne contient l'information à prédire.")
    if np.nan_to_num(res[best]["auc"], nan=0) < 0.6:
        lines.append("⚠️ Avec les variables disponibles, il n'est pas possible de prédire ce phénomène mieux qu'au hasard : "
                     "ne pas utiliser ce modèle pour décider.")
    return lines


def train_classif_scrap(prod, start, end, threshold_pct=4.0, machines=None):
    _need(prod, ["date", "qty_produced", "qty_rejected", "machine_code", "shift_name", "category", "target_group", "qty_planned"],
          "fact_production")
    df = _filter(prod, start, end, machines)
    df = df[df["qty_produced"] > 0].dropna(subset=["shift_name"]).copy()
    df["taux_rebut"] = 100.0 * df["qty_rejected"] / df["qty_produced"]
    df["rebut_eleve"] = (df["taux_rebut"] >= threshold_pct).astype(int)
    df["mois"], df["jour_semaine"] = df["date"].dt.month, df["date"].dt.dayofweek
    cat, num = ["machine_code", "shift_name", "category", "target_group"], ["qty_planned", "mois", "jour_semaine"]
    res, fitted, preds, info, warns = _classify(df, "date", cat, num, "rebut_eleve", "rebut élevé")
    interp = _interpret_classif(res, info, "rebut élevé")
    interp.insert(0, f"Un « lot » = une machine pendant une équipe ; **rebut élevé** = taux de rebut ≥ {threshold_pct:.1f} %. "
                     "Seules les informations connues avant la production sont utilisées (machine, équipe, produit, quantité planifiée, calendrier).")
    return {"models": res, "info": info, "predictions": preds, "warnings": warns, "interpretation": interp,
            "label": "rebut élevé", "threshold": threshold_pct}, fitted


def train_classif_late(orders, start, end):
    _need(orders, ["order_date", "due_date", "delivery_date", "qty_ordered", "unit_price", "client_name", "segment", "category"], "fact_orders")
    df = orders[(orders["order_date"] >= pd.Timestamp(start)) & (orders["order_date"] <= pd.Timestamp(end))].copy()
    df = df.dropna(subset=["order_date", "due_date", "delivery_date"])           # seulement les lignes déjà livrées
    df["retard"] = (df["delivery_date"] > df["due_date"]).astype(int)
    df["delai_jours"] = (df["due_date"] - df["order_date"]).dt.days
    df["mois_commande"] = df["order_date"].dt.month
    cat, num = ["client_name", "segment", "category"], ["qty_ordered", "delai_jours", "mois_commande", "unit_price"]
    res, fitted, preds, info, warns = _classify(df, "order_date", cat, num, "retard", "en retard", min_rows=300)
    interp = _interpret_classif(res, info, "en retard")
    interp.insert(0, "Ligne livrée **en retard** = date de livraison postérieure à la date d'échéance. Seules les lignes déjà livrées "
                     "sont utilisées ; les variables sont connues à la commande (client, produit, quantité, délai promis, mois).")
    return {"models": res, "info": info, "predictions": preds, "warnings": warns, "interpretation": interp,
            "label": "en retard", "threshold": None}, fitted


# ----------------------------------------------------------------------------- 2b. Détection d'anomalies
ANOM_FEATS = {"prod_par_equipe": "production par équipe", "taux_rebut": "taux de rebut",
              "arret_par_equipe": "heures d'arrêt par équipe", "atteinte_plan": "atteinte du plan"}


def train_anomalies(prod, start, end, contamination=0.02, machines=None):
    _need(prod, ["date", "machine_code", "qty_produced", "qty_rejected", "qty_planned", "downtime_hours"], "fact_production")
    df = _filter(prod, start, end, machines)
    g = df.groupby(["date", "machine_code"]).agg(produit=("qty_produced", "sum"), rebut=("qty_rejected", "sum"),
                                                  planifie=("qty_planned", "sum"), arret=("downtime_hours", "sum"),
                                                  equipes=("qty_produced", "size")).reset_index()
    g = g[g["produit"] > 0].copy()
    if len(g) < 200:
        raise MLDataError(f"Seulement {len(g)} jours-machine : il en faut au moins 200 pour détecter des anomalies.")
    g["prod_par_equipe"] = g["produit"] / g["equipes"]
    g["taux_rebut"] = 100.0 * g["rebut"] / g["produit"]
    g["arret_par_equipe"] = g["arret"] / g["equipes"]
    g["atteinte_plan"] = np.where(g["planifie"] > 0, 100.0 * g["produit"] / g["planifie"], np.nan)
    feats = list(ANOM_FEATS)
    g["atteinte_plan"] = g.groupby("machine_code")["atteinte_plan"].transform(lambda s: s.fillna(s.median()))
    train, _, cutoff = _split_by_date(g, "date", 0.2)
    stats = train.groupby("machine_code")[feats].agg(["mean", "std"])
    Z = pd.DataFrame(index=g.index, columns=feats, dtype=float)
    for m, idx in g.groupby("machine_code").groups.items():
        for f in feats:
            mu, sd = stats.loc[m, (f, "mean")], stats.loc[m, (f, "std")]
            Z.loc[idx, f] = (g.loc[idx, f] - mu) / (sd if sd and sd > 0 else 1.0)
    Z = Z.fillna(0.0)
    model = IsolationForest(n_estimators=300, contamination=contamination, random_state=SEED).fit(Z.loc[train.index])
    g["score"] = -model.decision_function(Z)                 # plus grand = plus anormal
    g["anomalie"] = model.predict(Z) == -1
    zmax = Z.abs().idxmax(axis=1)
    reasons = []
    for i in g.index:
        f, z = zmax[i], Z.loc[i, zmax[i]]
        reasons.append(f"{ANOM_FEATS[f]} anormalement {'élevé(e)' if z > 0 else 'bas(se)'} ({z:+.1f} écarts-types)")
    g["raison"] = reasons
    flagged = g[g["anomalie"]].sort_values("score", ascending=False)
    per_machine = (g.groupby("machine_code")["anomalie"].agg(["sum", "size"]).rename(columns={"sum": "Anomalies", "size": "Jours"})
                   .assign(**{"Part (%)": lambda d: 100 * d["Anomalies"] / d["Jours"]}).reset_index()
                   .rename(columns={"machine_code": "Machine"}).sort_values("Anomalies", ascending=False))
    recent = flagged[flagged["date"] >= cutoff]
    top_m = per_machine.iloc[0]
    interp = [f"{len(flagged)} jours-machine anormaux sur {len(g)} (≈ {100 * len(flagged) / len(g):.1f} %), "
              f"dont **{len(recent)}** depuis le {pd.Timestamp(cutoff).date()} (période récente, jugée d'après les normes du passé).",
              f"Chaque machine est comparée à **ses propres habitudes** (pas à une moyenne globale) : une machine structurellement "
              f"moins bonne n'est donc pas signalée en permanence. Machine avec le plus d'anomalies : **{top_m['Machine']}** "
              f"({int(top_m['Anomalies'])} jours)."]
    if len(flagged):
        r = flagged.iloc[0]
        interp.append(f"Cas le plus atypique : {r['machine_code']} le {r['date'].date()} — {r['raison']}.")
    results = {"all": g[["date", "machine_code"] + feats + ["score", "anomalie", "raison"]], "flagged": flagged[["date", "machine_code"] + feats + ["score", "raison"]],
               "per_machine": per_machine, "cutoff": str(pd.Timestamp(cutoff).date()), "contamination": contamination,
               "interpretation": interp, "warnings": []}
    return results, model
