"""TEMASA - Assistant de données : questions en français -> SQL en lecture seule -> réponse, tableau, graphique."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import streamlit as st

import auth
import charts
import db
import llm
import settings
import sql_guard

st.set_page_config(page_title="TEMASA – Assistant", page_icon="💬", layout="wide")
auth.require_login()

st.title("💬 Assistant de données")
st.caption("Posez une question sur la production, la qualité, les commandes ou le stock. "
           "Les requêtes sont en **lecture seule** (SELECT uniquement, limitées à "
           f"{settings.MAX_ROWS} lignes et {settings.QUERY_TIMEOUT} s).")

EXAMPLES = [
    "Quelle est la production totale par mois en 2026 ?",
    "Quelles machines ont le plus fort taux de rebut ?",
    "Top 5 des défauts les plus fréquents",
    "Quel est le taux de livraison à temps par client ?",
    "Quels produits sont sous le stock minimum ?",
    "Chiffre d'affaires par pays",
    "Production de collants vs chaussettes par mois",
]

if not db.is_configured():
    st.error("La base de données n'est pas configurée : contactez l'administrateur.")
    st.stop()
if not llm.is_configured():
    if auth.is_admin():
        st.error(llm.friendly_config_message())
    else:
        st.warning("L'assistant n'est pas encore configuré (clé API manquante). Contactez l'administrateur.")
    st.stop()
if auth.is_admin() and db.check_readonly_account() is False:
    st.warning("⚠️ Le compte SQL utilisé peut ÉCRIRE dans la base. Par sécurité, connectez l'application avec un compte "
               "qui n'a que le droit SELECT (voir sql/create_readonly_user.sql et le README).")

st.session_state.setdefault("chat", [])        # messages affichés
st.session_state.setdefault("history", [])     # [(question, sql)] pour les questions de suivi


def queue(q):
    st.session_state["queued"] = q


def reset_chat():
    st.session_state["chat"], st.session_state["history"] = [], []


with st.sidebar:
    st.button("🆕 Nouvelle conversation", on_click=reset_chat, width="stretch")
    st.subheader("Exemples")
    for i, ex in enumerate(EXAMPLES):
        st.button(ex, key=f"ex_{i}", on_click=queue, args=(ex,), width="stretch")
    st.caption("Seuls le schéma, votre question et les 50 premières lignes du résultat sont envoyés au modèle.")


def answer(question: str) -> dict:
    """Question -> {answer, sql, df, truncated, error}. Ne lève jamais d'exception vers l'interface."""
    out = {"role": "assistant", "answer": "", "sql": None, "df": None, "truncated": False, "error": None}
    try:
        note = db.schema_note()
        plan = llm.generate_sql(question, history=st.session_state["history"], schema_note=note)
        sql = plan.get("sql")
        if not sql:
            out["answer"] = plan.get("reply") or "Je ne peux pas répondre à cette question avec les données disponibles."
            return out
        for attempt in range(2):                                   # une réparation automatique si SQL Server refuse la requête
            try:
                df, truncated, safe = db.cached_query(sql)
            except sql_guard.SQLGuardError as e:
                out.update(sql=sql, error=f"Requête refusée par le garde-fou de sécurité : {e}")
                return out
            except Exception as e:
                err = db.friendly_error(e)
                out.update(sql=sql, error=err)
                if attempt == 0:
                    sql = llm.generate_sql(question, history=st.session_state["history"], error=err[:600],
                                           previous_sql=sql, schema_note=note).get("sql")
                    if sql:
                        continue
                return out
            out.update(sql=safe, df=df, truncated=truncated, error=None)
            out["answer"] = llm.explain_result(question, df, truncated)
            st.session_state["history"].append((question, safe))
            return out
    except llm.LLMError as e:
        out["error"] = str(e)
    except Exception as e:                                         # jamais de traceback brut devant l'utilisateur
        out["error"] = "Une erreur inattendue s'est produite : " + settings.redact(str(e))[:300]
    return out


def show(msg: dict, idx: int):
    if msg.get("answer"):
        st.markdown(msg["answer"])
    if msg.get("error"):
        st.error(msg["error"])
    df = msg.get("df")
    if df is not None:
        if msg.get("truncated"):
            st.warning(f"Résultat tronqué : seules les {settings.MAX_ROWS} premières lignes sont affichées.")
        st.dataframe(df, width="stretch", hide_index=True)
        fig = charts.auto_chart(df)
        if fig is not None:
            st.plotly_chart(fig, width="stretch", key=f"chart_{idx}")
        st.download_button("⬇️ Télécharger en CSV", df.to_csv(index=False).encode("utf-8-sig"),
                           file_name="resultat_temasa.csv", mime="text/csv", key=f"dl_{idx}")
    if msg.get("sql"):
        with st.expander("Voir la requête SQL"):
            st.code(msg["sql"], language="sql")


question = st.chat_input("Ex. : Quel est le taux de rebut par machine en 2026 ?")
question = st.session_state.pop("queued", None) or question

box = st.container()                       # les messages sont affichés UNE seule fois, dans ce conteneur
if question:
    st.session_state["chat"].append({"role": "user", "content": question})
with box:
    for i, m in enumerate(st.session_state["chat"]):
        with st.chat_message(m["role"]):
            if m["role"] == "user":
                st.markdown(m["content"])
            else:
                show(m, i)
    if question:
        with st.chat_message("assistant"):
            with st.spinner("Analyse en cours..."):
                res = answer(question)
            st.session_state["chat"].append(res)
            show(res, len(st.session_state["chat"]) - 1)
if not st.session_state["chat"]:
    st.info("👈 Choisissez un exemple dans la barre latérale ou écrivez votre question ci-dessous.")
