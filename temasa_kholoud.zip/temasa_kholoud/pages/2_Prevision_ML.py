"""TEMASA - Prévision & ML : régression, classification, détection d'anomalies (100 % local, sans coût)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
import streamlit as st

import auth
import charts
import db
import ml

st.set_page_config(page_title="TEMASA – Prévision & ML", page_icon="📈", layout="wide")
auth.require_login()
admin = auth.is_admin()

st.title("📈 Prévision & Machine Learning")
if not db.is_configured():
    st.error("La base de données n'est pas configurée : contactez l'administrateur.")
    st.stop()
miss = db.missing_tables()
if miss:
    st.error("Tables introuvables dans la base : " + ", ".join(miss) + ". Les modèles ne peuvent pas être entraînés.")
    st.stop()
try:
    prod, orders = db.load_production(), db.load_orders()
except Exception as e:
    st.error(db.friendly_error(e))
    st.stop()
dmin, dmax = prod["date"].min().date(), prod["date"].max().date()
odmin, odmax = orders["order_date"].min().date(), orders["order_date"].max().date()


def fnum(x, d=2):
    return "—" if x is None or x != x else f"{x:,.{d}f}".replace(",", " ")


def csv_btn(df, name, label="⬇️ Télécharger en CSV"):
    st.download_button(label, df.to_csv(index=False).encode("utf-8-sig"), file_name=name, mime="text/csv", key="dl_" + name)


# ----------------------------------------------------------------------------- barre latérale
with st.sidebar:
    st.header("Paramètres")
    task = st.radio("Analyse", list(ml.TASKS), format_func=ml.TASKS.get)
    bundle = ml.load_bundle(task)
    params, run = {}, False
    if admin:
        rng_min, rng_max = (odmin, odmax) if task == "classif_late" else (dmin, dmax)
        per = st.date_input("Période d'entraînement", (rng_min, rng_max), min_value=rng_min, max_value=rng_max)
        params["start"], params["end"] = (str(per[0]), str(per[-1])) if len(per) else (str(rng_min), str(rng_max))
        if task == "forecast":
            tname = st.selectbox("Cible", list(ml.TARGETS))
            g = st.radio("Granularité", ["Semaine", "Mois"], horizontal=True)
            params.update(target=ml.TARGETS[tname], freq="W" if g == "Semaine" else "M", horizon=st.slider("Horizon de prévision", 2, 26 if g == "Semaine" else 12, 8 if g == "Semaine" else 6))
            params["machines"] = st.multiselect("Machines", sorted(prod["machine_code"].unique()), placeholder="Toutes") or None
        elif task == "classif_scrap":
            params["threshold_pct"] = st.slider("Seuil de « rebut élevé » (%)", 2.0, 8.0, 4.0, 0.5)
        elif task == "anomalies":
            params["contamination"] = st.slider("Part d'anomalies attendue (%)", 1.0, 5.0, 2.0, 0.5) / 100
        run = st.button("🚀 Entraîner", type="primary", width="stretch")
    else:
        st.info("🔒 Lecture seule : seuls les administrateurs peuvent (ré)entraîner un modèle. Vous voyez ici le dernier modèle entraîné.")

if run:
    try:
        with st.spinner("Entraînement en cours..."):
            if task == "forecast":
                res, model = ml.train_forecast(prod, params["target"], params["freq"], params["start"], params["end"], params["machines"], params["horizon"])
            elif task == "scrap_drivers":
                res, model = ml.train_scrap_drivers(prod, params["start"], params["end"])
            elif task == "classif_scrap":
                res, model = ml.train_classif_scrap(prod, params["start"], params["end"], params["threshold_pct"])
            elif task == "classif_late":
                res, model = ml.train_classif_late(orders, params["start"], params["end"])
            else:
                res, model = ml.train_anomalies(prod, params["start"], params["end"], params["contamination"])
        bundle = ml.save_bundle(task, res, model, params, auth.current_user())
        st.toast("Modèle entraîné et sauvegardé ✅")
    except ml.MLDataError as e:
        st.error(f"⚠️ {e}")
    except Exception as e:
        st.error("L'entraînement a échoué : " + str(e)[:300])

st.subheader(ml.TASKS[task])
if bundle is None:
    st.info("Aucun modèle entraîné pour cette analyse." + (" Choisissez les paramètres puis cliquez sur « Entraîner »." if admin
                                                         else " Demandez à un administrateur de l'entraîner."))
    st.stop()

res, p = bundle["results"], bundle["params"]
extra = {"target": f" · cible : {p.get('target')}" if p.get("target") else ""}
st.caption(f"🗓️ Modèle entraîné le **{bundle['trained_at']}** par {bundle.get('trained_by') or '—'} · période : {p.get('start')} → {p.get('end')}{extra['target']}")
for w in res.get("warnings", []):
    st.warning(w)


def interpretation(lines):
    with st.container(border=True):
        st.markdown("**Interprétation**")
        for ln in lines:
            st.markdown("- " + ln)


# ----------------------------------------------------------------------------- affichage par tâche
if task == "forecast":
    names = ["Régression linéaire", "Random Forest", "Gradient Boosting"]
    shown = st.sidebar.selectbox("Modèle affiché", names, index=names.index(res["best"]))
    st.plotly_chart(charts.forecast_fig(res, shown), width="stretch")
    st.markdown("**Qualité sur la période de test** (jamais vue à l'entraînement) :")
    m = res["metrics"].copy()
    st.dataframe(m.style.format({"MAE": "{:,.1f}", "RMSE": "{:,.1f}", "R²": "{:.2f}", "MAE (validation croisée)": "{:,.1f}"}), width="stretch", hide_index=True)
    fc = res["forecasts"][shown].rename(columns={"periode": "Période", "prevision": "Prévision", "bas": "Bas (95 %)", "haut": "Haut (95 %)"})
    if shown != "Régression linéaire":
        st.caption("Bande approximative (± 1,96 × erreur de validation croisée) pour les modèles à arbres ; exacte pour la régression linéaire.")
    st.dataframe(fc.style.format({"Prévision": "{:,.1f}", "Bas (95 %)": "{:,.1f}", "Haut (95 %)": "{:,.1f}", "Période": "{:%d/%m/%Y}"}), width="stretch", hide_index=True)
    csv_btn(fc, f"prevision_{shown.replace(' ', '_')}.csv")
    interpretation(res["interpretation"])

elif task == "scrap_drivers":
    c = st.columns(4)
    c[0].metric("R²", fnum(res["r2"]), border=True)
    c[1].metric("R² ajusté", fnum(res["r2_adj"]), border=True)
    c[2].metric("R² sur période récente", fnum(res["holdout"]["r2"]), border=True, help="Modèle estimé sur le passé, testé sur les 20 % de jours les plus récents.")
    c[3].metric("Lignes analysées", f"{res['n']:,}".replace(",", " "), border=True)
    st.plotly_chart(charts.coef_fig(res["coefs"]), width="stretch")
    st.dataframe(res["coefs"].style.format({"Coefficient (points de %)": "{:+.3f}", "Erreur-type": "{:.3f}", "p-value": "{:.4f}", "IC 95 % bas": "{:+.3f}", "IC 95 % haut": "{:+.3f}"}),
                 width="stretch", hide_index=True)
    csv_btn(res["coefs"], "coefficients_rebut.csv")
    interpretation(res["interpretation"])
    with st.expander("Diagnostic : résidus"):
        st.plotly_chart(charts.residual_fig(res["residuals"]), width="stretch")

elif task in ("classif_scrap", "classif_late"):
    kinds = list(res["models"])
    kind = st.sidebar.selectbox("Modèle affiché", kinds, index=max(range(len(kinds)), key=lambda i: res["models"][kinds[i]]["auc"] if res["models"][kinds[i]]["auc"] == res["models"][kinds[i]]["auc"] else 0))
    r, info = res["models"][kind], res["info"]
    c = st.columns(6)
    for col, (lab, key) in zip(c, [("Exactitude", "accuracy"), ("Précision", "precision"), ("Rappel", "recall"), ("F1", "f1"), ("ROC-AUC (test)", "auc"), ("ROC-AUC (valid. croisée)", "cv_auc")]):
        col.metric(lab, fnum(r[key]), border=True)
    st.caption(f"Entraînement : {info['n_train']} cas jusqu'au {info['cutoff']} · test : {info['n_test']} cas après cette date · "
               f"part de « {res['label']} » : {info['pos_rate_train'] * 100:.0f} % (train) / {info['pos_rate_test'] * 100:.0f} % (test).")
    a, b, d = st.columns(3)
    with a:
        st.plotly_chart(charts.confusion_fig(r["confusion"], ["Non", "Oui"]), width="stretch")
    with b:
        st.plotly_chart(charts.roc_fig(r["roc"], r["auc"]), width="stretch")
    with d:
        st.plotly_chart(charts.importance_fig(r["importance"]), width="stretch")
    interpretation(res["interpretation"])
    pr = res["predictions"]
    csv_btn(pr, f"predictions_{task}.csv", "⬇️ Télécharger les prédictions du test (CSV)")

else:
    c = st.columns(3)
    c[0].metric("Jours-machine anormaux", len(res["flagged"]), border=True)
    c[1].metric("Jours-machine analysés", f"{len(res['all']):,}".replace(",", " "), border=True)
    c[2].metric("Part d'anomalies attendue", f"{res['contamination'] * 100:.1f} %", border=True)
    interpretation(res["interpretation"])
    a, b = st.columns([1, 2])
    with a:
        st.markdown("**Anomalies par machine**")
        st.dataframe(res["per_machine"].style.format({"Part (%)": "{:.1f}"}), width="stretch", hide_index=True)
    with b:
        mach = st.selectbox("Machine", sorted(res["all"]["machine_code"].unique()))
        feat = st.selectbox("Indicateur", list(ml.ANOM_FEATS), format_func=ml.ANOM_FEATS.get)
        st.plotly_chart(charts.anomaly_fig(res["all"], mach, feat, ml.ANOM_FEATS[feat]), width="stretch")
    st.markdown("**Jours-machine signalés (les plus atypiques d'abord)**")
    fl = res["flagged"].rename(columns={"date": "Date", "machine_code": "Machine", "raison": "Raison principale", "score": "Score"})
    st.dataframe(fl.style.format({"Date": "{:%d/%m/%Y}", "Score": "{:.3f}", "prod_par_equipe": "{:,.0f}", "taux_rebut": "{:.2f}", "arret_par_equipe": "{:.2f}", "atteinte_plan": "{:.1f}"}), width="stretch", hide_index=True, height=360)
    csv_btn(fl, "anomalies.csv")
