"""TEMASA - Administration (réservée aux administrateurs) : état de la configuration, tests, comptes, modèles."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import streamlit as st

import auth
import db
import llm
import ml
import settings

st.set_page_config(page_title="TEMASA – Administration", page_icon="⚙️", layout="wide")
auth.require_login(admin_only=True)

st.title("⚙️ Administration")
st.caption("Les clés API et la connexion à la base se configurent dans les fichiers `.env` ou `.streamlit/secrets.toml` "
           "(jamais dans l'interface). Aucune valeur secrète n'est affichée ici.")

st.subheader("Configuration")
ok, no = "✅ configurée", "❌ manquante"
prov = llm.provider()
c = st.columns(3)
c[0].metric("Fournisseur de modèle", prov.capitalize(), border=True)
c[1].metric("Modèle", llm.model_name(), border=True)
c[2].metric("Clé API", ok if llm.is_configured() else no, border=True)
c = st.columns(3)
c[0].metric("Base de données", ok if db.is_configured() else no, border=True)
c[1].metric("Limite de lignes", settings.MAX_ROWS, border=True)
c[2].metric("Durée max. d'une requête", f"{settings.QUERY_TIMEOUT} s", border=True)
if not llm.is_configured():
    st.error(llm.friendly_config_message())

st.subheader("Tests")
a, b, d = st.columns(3)
with a:
    if st.button("Tester la base de données", width="stretch"):
        good, msg = db.test_connection() if db.is_configured() else (False, "Base non configurée (DB_SERVER ou DB_URL).")
        (st.success if good else st.error)(msg)
with b:
    if st.button("Tester la clé du modèle", width="stretch"):
        try:
            with st.spinner("Appel du modèle..."):
                out = llm.complete("Réponds uniquement par le mot OK.", [{"role": "user", "content": "Test"}], max_tokens=20)
            st.success(f"Le modèle « {llm.model_name()} » répond : {out[:40]}")
        except llm.LLMError as e:
            st.error(str(e))
with d:
    if st.button("Vérifier le compte SQL", width="stretch"):
        ro = db.check_readonly_account() if db.is_configured() else None
        if ro is True:
            st.success("Le compte SQL est en lecture seule ✅")
        elif ro is False:
            st.error("Le compte SQL peut ÉCRIRE dans la base. Utilisez un compte avec le seul droit SELECT (sql/create_readonly_user.sql).")
        else:
            st.info("Impossible de vérifier (base non SQL Server ou droits insuffisants).")

if prov == "gemini" and llm.is_configured():
    if st.button("Lister les modèles Gemini disponibles pour ma clé"):
        try:
            names = llm.list_gemini_models()
            ranked = llm.rank_gemini_models(names)
            st.success(f"Modèle utilisé automatiquement : **{ranked[0] if ranked else llm.model_name()}** "
                       "(le plus récent « flash » stable). Pour en imposer un autre : `GEMINI_MODEL=nom` dans `.env`.")
            st.code("\n".join(names) or "(aucun)")
        except llm.LLMError as e:
            st.error(str(e))

st.subheader("Comptes utilisateurs")
users = auth.users_table()
st.dataframe(users, width="stretch", hide_index=True)
locked = [u["Utilisateur"] for u in users if u["Verrouillé"]]
if locked:
    who = st.selectbox("Compte verrouillé à débloquer", locked)
    if st.button("🔓 Déverrouiller"):
        auth.unlock_user(who)
        st.success(f"{who} déverrouillé.")
        st.rerun()
st.caption("Pour ajouter ou supprimer un compte : `python create_user.py` (ou `--delete NOM`).")

st.subheader("Modèles de Machine Learning enregistrés")
st.dataframe(ml.list_bundles(), width="stretch", hide_index=True)
