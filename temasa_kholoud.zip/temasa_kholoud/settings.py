"""
Lecture de la configuration.
Ordre de priorité : st.secrets (.streamlit/secrets.toml)  >  variables d'environnement / fichier .env

Les valeurs secrètes (clés API, mot de passe SQL) ne sont JAMAIS affichées dans l'interface :
utilisez is_set() pour savoir si elles existent et redact() pour nettoyer un message d'erreur.
"""
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

SECRET_NAMES = ("ANTHROPIC_API_KEY", "GEMINI_API_KEY", "DB_PASSWORD", "DB_URL")


def get(name: str, default=None):
    """Valeur de configuration (nettoyée des espaces) ou `default`."""
    value = None
    try:
        import streamlit as st
        if name in st.secrets:
            value = st.secrets[name]
    except Exception:           # pas de fichier secrets.toml : on passe aux variables d'environnement
        value = None
    if value is None or str(value).strip() == "":
        value = os.getenv(name)
    if value is None or str(value).strip() == "":
        return default
    return str(value).strip()


def get_int(name: str, default: int) -> int:
    try:
        return int(get(name, default))
    except (TypeError, ValueError):
        return default


def is_set(name: str) -> bool:
    return get(name) is not None


def redact(text: str) -> str:
    """Remplace toute valeur secrète présente dans `text` par ***."""
    text = str(text)
    for n in SECRET_NAMES:
        v = get(n)
        if v and len(v) >= 6:
            text = text.replace(v, "***")
    return text


MODELS_DIR = Path(get("MODELS_DIR", str(BASE_DIR / "models")))
MAX_ROWS = get_int("SQL_MAX_ROWS", 500)           # lignes maximum renvoyées par une requête de l'assistant
QUERY_TIMEOUT = get_int("SQL_TIMEOUT_SECONDS", 30)  # durée maximum d'une requête (secondes)
