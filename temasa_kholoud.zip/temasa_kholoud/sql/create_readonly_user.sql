/* =====================================================================
   Compte SQL en LECTURE SEULE pour l'application (SQL Server).
   À exécuter dans SSMS par un administrateur SQL. Remplacez le mot de passe.
   Ensuite, dans .env :  DB_USER=temasa_reader   DB_PASSWORD=<le mot de passe>
   (le serveur doit accepter l'authentification SQL : "mode mixte")
   ===================================================================== */
USE master;
GO
CREATE LOGIN temasa_reader WITH PASSWORD = 'CHANGEZ-MOI-Mot2Passe!Long', CHECK_POLICY = ON;
GO
USE temasa_dw;
GO
CREATE USER temasa_reader FOR LOGIN temasa_reader;
GRANT SELECT ON SCHEMA::dbo TO temasa_reader;      -- lecture seule : aucun INSERT / UPDATE / DELETE / EXEC
GO
-- Vérification (doit renvoyer 0 pour chaque colonne) :
EXECUTE AS USER = 'temasa_reader';
SELECT HAS_PERMS_BY_NAME('dbo.fact_orders','OBJECT','INSERT') AS can_insert,
       HAS_PERMS_BY_NAME('dbo.fact_orders','OBJECT','UPDATE') AS can_update,
       HAS_PERMS_BY_NAME('dbo.fact_orders','OBJECT','DELETE') AS can_delete;
REVERT;
GO
