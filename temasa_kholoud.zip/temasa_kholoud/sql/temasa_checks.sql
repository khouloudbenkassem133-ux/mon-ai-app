/* =====================================================================
   TEMASA - Step 3: check the numbers after loading (SQL Server / T-SQL)
   Run after clean_and_load.py. Expected values are for temasa_data.xlsx.
   ===================================================================== */
USE temasa_dw;
GO

/* ---- 1. Row counts ------------------------------------------------- */
-- Expected: dim_product 38, dim_machine 12, dim_client 14, dim_defect_type 8,
--           fact_production 13805, fact_quality 17918, fact_orders 1296, fact_stock 798
SELECT 'dim_product' AS tbl, COUNT(*) AS n FROM dim_product
UNION ALL SELECT 'dim_machine',     COUNT(*) FROM dim_machine
UNION ALL SELECT 'dim_client',      COUNT(*) FROM dim_client
UNION ALL SELECT 'dim_defect_type', COUNT(*) FROM dim_defect_type
UNION ALL SELECT 'fact_production', COUNT(*) FROM fact_production
UNION ALL SELECT 'fact_quality',    COUNT(*) FROM fact_quality
UNION ALL SELECT 'fact_orders',     COUNT(*) FROM fact_orders
UNION ALL SELECT 'fact_stock',      COUNT(*) FROM fact_stock;

/* ---- 2. Control totals (must match the clean_and_load.py report) --- */
-- Expected: produced 40,918,166 | rejected 1,156,553
SELECT SUM(qty_produced) AS total_produced, SUM(qty_rejected) AS total_rejected
FROM fact_production;
-- Expected: ordered 10,797,300 | delivered 10,067,020
SELECT SUM(qty_ordered) AS total_ordered, SUM(qty_delivered) AS total_delivered
FROM fact_orders;

/* ---- 3. Duplicates (expected: 0 rows) ------------------------------ */
SELECT date_key, machine_key, shift_key, COUNT(*) AS n
FROM fact_production
GROUP BY date_key, machine_key, shift_key
HAVING COUNT(*) > 1;

/* ---- 4. Business-rule violations (expected: 0 for each) ------------ */
SELECT 'rejected > produced'      AS rule_name, COUNT(*) AS violations FROM fact_production WHERE qty_rejected > qty_produced
UNION ALL SELECT 'negative quantities',      COUNT(*) FROM fact_production WHERE qty_produced < 0 OR qty_rejected < 0
UNION ALL SELECT 'hours not equal to 8',     COUNT(*) FROM fact_production WHERE ABS(run_hours + downtime_hours - 8) > 0.01
UNION ALL SELECT 'delivered > ordered',      COUNT(*) FROM fact_orders WHERE qty_delivered > qty_ordered
UNION ALL SELECT 'due date before order',    COUNT(*) FROM fact_orders WHERE due_date_key < order_date_key
UNION ALL SELECT 'delivery before order',    COUNT(*) FROM fact_orders WHERE delivery_date_key < order_date_key
UNION ALL SELECT 'stock negative',           COUNT(*) FROM fact_stock WHERE qty_on_hand < 0;

/* ---- 5. Missing values (qty_planned blanks come from the Excel) ---- */
SELECT SUM(CASE WHEN qty_planned IS NULL THEN 1 ELSE 0 END) AS null_qty_planned,
       SUM(CASE WHEN run_hours   IS NULL THEN 1 ELSE 0 END) AS null_run_hours
FROM fact_production;

/* ---- 6. Reconciliation production <-> quality (expected: 0 rows) --- */
-- Rejects declared in Production must equal defects declared in Quality, per month.
SELECT p.ym, p.rejected, q.defective, p.rejected - q.defective AS difference
FROM (SELECT date_key / 100 AS ym, SUM(qty_rejected)  AS rejected  FROM fact_production GROUP BY date_key / 100) p
JOIN (SELECT date_key / 100 AS ym, SUM(qty_defective) AS defective FROM fact_quality    GROUP BY date_key / 100) q
  ON p.ym = q.ym
WHERE p.rejected <> q.defective;

/* ---- 7. Business insights that must look plausible ----------------- */
-- 7a. Reject rate by machine: MC-04 and MC-08 should be clearly the worst (~6%)
SELECT m.machine_code, m.department,
       SUM(f.qty_produced) AS produced,
       CAST(100.0 * SUM(f.qty_rejected) / SUM(f.qty_produced) AS DECIMAL(5,2)) AS reject_pct
FROM fact_production f JOIN dim_machine m ON m.machine_key = f.machine_key
GROUP BY m.machine_code, m.department
ORDER BY reject_pct DESC;

-- 7b. Seasonality: tights (Collants) production should peak Oct-Feb
SELECT date_key / 100 AS year_month, p.category, SUM(f.qty_produced) AS produced
FROM fact_production f JOIN dim_product p ON p.product_key = f.product_key
GROUP BY date_key / 100, p.category
ORDER BY year_month, p.category;

-- 7c. Defects by type (Pareto)
SELECT d.defect_name, d.defect_family, SUM(q.qty_defective) AS total_defects,
       CAST(100.0 * SUM(q.qty_defective) / SUM(SUM(q.qty_defective)) OVER () AS DECIMAL(5,2)) AS pct
FROM fact_quality q JOIN dim_defect_type d ON d.defect_type_key = q.defect_type_key
GROUP BY d.defect_name, d.defect_family
ORDER BY total_defects DESC;

-- 7d. On-time delivery rate and fill rate
-- Expected: on-time about 74%, fill rate about 99.2%
SELECT CAST(100.0 * SUM(CASE WHEN delivery_date_key <= due_date_key THEN 1 ELSE 0 END)
            / COUNT(*) AS DECIMAL(5,2)) AS on_time_pct,
       COUNT(*) AS delivered_lines
FROM fact_orders WHERE delivery_date_key IS NOT NULL;

SELECT CAST(100.0 * SUM(qty_delivered) / SUM(qty_ordered) AS DECIMAL(5,2)) AS fill_rate_pct
FROM fact_orders WHERE delivery_date_key IS NOT NULL;

-- 7e. Products below minimum stock at the latest snapshot
SELECT p.product_code, p.product_name, s.qty_on_hand, s.min_stock_level
FROM fact_stock s JOIN dim_product p ON p.product_key = s.product_key
WHERE s.date_key = (SELECT MAX(date_key) FROM fact_stock)
  AND s.qty_on_hand < s.min_stock_level
ORDER BY s.qty_on_hand - s.min_stock_level;

-- 7f. Revenue by client segment
SELECT c.segment, c.country, SUM(o.qty_delivered * o.unit_price) AS revenue_mad
FROM fact_orders o JOIN dim_client c ON c.client_key = o.client_key
GROUP BY c.segment, c.country
ORDER BY revenue_mad DESC;
