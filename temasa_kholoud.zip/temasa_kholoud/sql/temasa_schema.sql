/* =====================================================================
   TEMASA (Tétouan Maille) - Star schema for production / quality /
   orders / stock analysis.  Target: SQL Server (T-SQL).
   NOTE: column names are ASSUMPTIONS - adapt them to the real Excel.
   ===================================================================== */

CREATE DATABASE temasa_dw;
GO
USE temasa_dw;
GO

/* ---------- STAGING (raw copy of the Excel sheets) -------------------- */
CREATE SCHEMA stg;
GO
-- Load each Excel sheet as-is here (Import Wizard / pandas), then clean
-- and transform into the dim/fact tables below.
-- Example:
-- CREATE TABLE stg.production_raw (
--     date_prod NVARCHAR(50), machine NVARCHAR(50), shift NVARCHAR(20),
--     product_code NVARCHAR(50), qty_produced NVARCHAR(50), qty_rejected NVARCHAR(50)
-- );

/* ---------- DIMENSIONS ------------------------------------------------ */
-- Surrogate keys of dim_product / dim_machine / dim_client / dim_defect_type are
-- assigned by clean_and_load.py (no IDENTITY), so the loader can map facts to keys.
CREATE TABLE dim_date (
    date_key      INT          PRIMARY KEY,      -- yyyymmdd
    full_date     DATE         NOT NULL UNIQUE,
    year          SMALLINT     NOT NULL,
    quarter       TINYINT      NOT NULL,
    month         TINYINT      NOT NULL,
    month_name    NVARCHAR(20) NOT NULL,
    week_of_year  TINYINT      NOT NULL,
    day_of_week   TINYINT      NOT NULL,
    day_name      NVARCHAR(20) NOT NULL,
    is_weekend    BIT          NOT NULL
);

CREATE TABLE dim_product (
    product_key   INT PRIMARY KEY,
    product_code  NVARCHAR(50)  NOT NULL UNIQUE,
    product_name  NVARCHAR(150) NULL,
    category      NVARCHAR(30)  NOT NULL
                  CHECK (category IN ('Chaussettes','Collants','Autre')),
    target_group  NVARCHAR(20)  NULL,            -- Homme / Femme / Enfant
    size          NVARCHAR(20)  NULL,
    color         NVARCHAR(30)  NULL,
    quality_grade NVARCHAR(20)  NULL,
    unit_cost     DECIMAL(10,2) NULL
);

CREATE TABLE dim_machine (
    machine_key   INT PRIMARY KEY,
    machine_code  NVARCHAR(50)  NOT NULL UNIQUE,
    machine_type  NVARCHAR(50)  NULL,
    department    NVARCHAR(50)  NULL,            -- Tricotage, Confection, Teinture...
    capacity_per_shift INT      NULL
);

CREATE TABLE dim_client (
    client_key    INT PRIMARY KEY,
    client_code   NVARCHAR(50)  NOT NULL UNIQUE,
    client_name   NVARCHAR(150) NULL,
    country       NVARCHAR(60)  NULL,
    segment       NVARCHAR(30)  NULL             -- Export / Local
);

CREATE TABLE dim_shift (
    shift_key     TINYINT PRIMARY KEY,
    shift_name    NVARCHAR(20) NOT NULL          -- Matin / Après-midi / Nuit
);

CREATE TABLE dim_defect_type (
    defect_type_key INT PRIMARY KEY,
    defect_name     NVARCHAR(100) NOT NULL UNIQUE,
    defect_family   NVARCHAR(50)  NULL           -- Tricotage, Couture, Teinture...
);

/* ---------- FACTS ----------------------------------------------------- */
CREATE TABLE fact_production (
    production_id   BIGINT IDENTITY(1,1) PRIMARY KEY,
    date_key        INT NOT NULL REFERENCES dim_date(date_key),
    product_key     INT NOT NULL REFERENCES dim_product(product_key),
    machine_key     INT NOT NULL REFERENCES dim_machine(machine_key),
    shift_key       TINYINT NULL REFERENCES dim_shift(shift_key),
    qty_planned     INT NULL,
    qty_produced    INT NOT NULL CHECK (qty_produced >= 0),
    qty_rejected    INT NOT NULL DEFAULT 0 CHECK (qty_rejected >= 0),
    run_hours       DECIMAL(6,2) NULL,
    downtime_hours  DECIMAL(6,2) NULL
);

CREATE TABLE fact_quality (
    quality_id      BIGINT IDENTITY(1,1) PRIMARY KEY,
    date_key        INT NOT NULL REFERENCES dim_date(date_key),
    product_key     INT NOT NULL REFERENCES dim_product(product_key),
    machine_key     INT NULL REFERENCES dim_machine(machine_key),
    defect_type_key INT NOT NULL REFERENCES dim_defect_type(defect_type_key),
    qty_defective   INT NOT NULL CHECK (qty_defective >= 0)
);

CREATE TABLE fact_orders (
    order_line_id   BIGINT IDENTITY(1,1) PRIMARY KEY,
    order_number    NVARCHAR(50) NOT NULL,
    order_date_key  INT NOT NULL REFERENCES dim_date(date_key),
    due_date_key    INT NULL REFERENCES dim_date(date_key),
    delivery_date_key INT NULL REFERENCES dim_date(date_key),
    client_key      INT NOT NULL REFERENCES dim_client(client_key),
    product_key     INT NOT NULL REFERENCES dim_product(product_key),
    qty_ordered     INT NOT NULL,
    qty_delivered   INT NOT NULL DEFAULT 0,
    unit_price      DECIMAL(10,2) NULL
);

CREATE TABLE fact_stock (
    stock_id        BIGINT IDENTITY(1,1) PRIMARY KEY,
    date_key        INT NOT NULL REFERENCES dim_date(date_key),   -- snapshot date
    product_key     INT NOT NULL REFERENCES dim_product(product_key),
    qty_on_hand     INT NOT NULL,
    min_stock_level INT NULL
);

/* ---------- INDEXES (for BI / assistant queries) ---------------------- */
CREATE INDEX ix_prod_date    ON fact_production(date_key);
CREATE INDEX ix_prod_product ON fact_production(product_key);
CREATE INDEX ix_prod_machine ON fact_production(machine_key);
CREATE INDEX ix_qual_date    ON fact_quality(date_key);
CREATE INDEX ix_ord_client   ON fact_orders(client_key);
CREATE INDEX ix_ord_date     ON fact_orders(order_date_key);
CREATE INDEX ix_stock_date   ON fact_stock(date_key, product_key);
GO

/* ---------- POPULATE dim_date (2022-01-01 -> 2030-12-31) -------------- */
SET LANGUAGE French;
;WITH d AS (
    SELECT CAST('2022-01-01' AS DATE) AS dt
    UNION ALL
    SELECT DATEADD(DAY, 1, dt) FROM d WHERE dt < '2030-12-31'
)
INSERT INTO dim_date
SELECT CONVERT(INT, FORMAT(dt,'yyyyMMdd')), dt, YEAR(dt), DATEPART(QUARTER,dt),
       MONTH(dt), DATENAME(MONTH,dt), DATEPART(ISO_WEEK,dt),
       ((DATEPART(WEEKDAY,dt)+@@DATEFIRST-2)%7)+1,   -- 1 = Monday
       DATENAME(WEEKDAY,dt),
       CASE WHEN ((DATEPART(WEEKDAY,dt)+@@DATEFIRST-2)%7)+1 >= 6 THEN 1 ELSE 0 END
FROM d OPTION (MAXRECURSION 0);

INSERT INTO dim_shift VALUES (1,'Matin'),(2,'Après-midi'),(3,'Nuit');
GO

/* ---------- READY-MADE VIEWS FOR POWER BI ----------------------------- */
CREATE VIEW vw_production AS
SELECT f.production_id, d.full_date, d.year, d.month, d.month_name,
       p.product_code, p.category, p.target_group,
       m.machine_code, m.department, s.shift_name,
       f.qty_planned, f.qty_produced, f.qty_rejected,
       f.run_hours, f.downtime_hours
FROM fact_production f
JOIN dim_date d    ON d.date_key    = f.date_key
JOIN dim_product p ON p.product_key = f.product_key
JOIN dim_machine m ON m.machine_key = f.machine_key
LEFT JOIN dim_shift s ON s.shift_key = f.shift_key;
GO

CREATE VIEW vw_orders AS
SELECT o.order_line_id, o.order_number,
       od.full_date AS order_date, dd.full_date AS due_date, dl.full_date AS delivery_date,
       c.client_name, c.country, c.segment,
       p.product_code, p.category,
       o.qty_ordered, o.qty_delivered, o.unit_price,
       o.qty_delivered * o.unit_price AS revenue
FROM fact_orders o
JOIN dim_date od ON od.date_key = o.order_date_key
LEFT JOIN dim_date dd ON dd.date_key = o.due_date_key
LEFT JOIN dim_date dl ON dl.date_key = o.delivery_date_key
JOIN dim_client c  ON c.client_key  = o.client_key
JOIN dim_product p ON p.product_key = o.product_key;
GO

/* ---------- READ-ONLY USER FOR THE AI ASSISTANT ----------------------- */
-- CREATE LOGIN ai_reader WITH PASSWORD = '<<choose a strong password>>';
-- CREATE USER ai_reader FOR LOGIN ai_reader;
-- GRANT SELECT ON SCHEMA::dbo TO ai_reader;     -- SELECT only, nothing else

/* ---------- SANITY-CHECK QUERIES (compare against the Excel) ---------- */
-- Total production per month
SELECT year, month, SUM(qty_produced) AS produced, SUM(qty_rejected) AS rejected,
       CAST(100.0*SUM(qty_rejected)/NULLIF(SUM(qty_produced),0) AS DECIMAL(5,2)) AS reject_pct
FROM vw_production GROUP BY year, month ORDER BY year, month;

-- Top 10 defect types
SELECT TOP 10 dt.defect_name, SUM(q.qty_defective) AS total_defects
FROM fact_quality q JOIN dim_defect_type dt ON dt.defect_type_key = q.defect_type_key
GROUP BY dt.defect_name ORDER BY total_defects DESC;

-- On-time delivery rate
SELECT CAST(100.0*SUM(CASE WHEN delivery_date <= due_date THEN 1 ELSE 0 END)
       / NULLIF(COUNT(*),0) AS DECIMAL(5,2)) AS on_time_pct
FROM vw_orders WHERE delivery_date IS NOT NULL;
