"""
Garde-fou SQL : le SQL est écrit par un modèle de langage, on ne lui fait donc JAMAIS confiance.

check_sql() accepte uniquement UNE requête SELECT (ou WITH ... SELECT, UNION) qui :
  - est analysée par un vrai parseur (sqlglot, dialecte T-SQL), pas seulement par des mots-clés ;
  - ne contient ni commentaire, ni second statement, ni mot-clé d'écriture / d'exécution ;
  - ne lit que les tables et vues autorisées (pas de sys.*, INFORMATION_SCHEMA, OPENROWSET...) ;
  - reçoit une limite de lignes (TOP n) imposée côté serveur.
Elle renvoie le SQL "propre" à exécuter, ou lève SQLGuardError (message en français).

Cela ne remplace pas un compte SQL en lecture seule (voir README) : c'est la 2e ligne de défense.
"""
import re

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError


class SQLGuardError(ValueError):
    """Requête refusée (le message est destiné à l'utilisateur)."""


ALLOWED_TABLES = {
    "dim_date", "dim_product", "dim_machine", "dim_client", "dim_shift", "dim_defect_type",
    "fact_production", "fact_quality", "fact_orders", "fact_stock",
    "vw_production", "vw_orders",
}

FORBIDDEN_WORDS = [
    "insert", "update", "delete", "drop", "alter", "create", "truncate", "merge", "exec", "execute",
    "grant", "revoke", "deny", "into", "openrowset", "openquery", "opendatasource", "openjson", "bulk",
    "waitfor", "shutdown", "backup", "restore", "dbcc", "kill", "use", "declare", "set", "go",
    "xp_cmdshell", "reconfigure", "load", "attach", "detach", "pragma",
]

FORBIDDEN_NODES = tuple(
    getattr(exp, name) for name in (
        "Insert", "Update", "Delete", "Drop", "Alter", "Create", "Merge", "Command", "Into",
        "TruncateTable", "Use", "Set", "Execute", "Grant", "Pragma", "Declare",
    ) if hasattr(exp, name)
)
SET_OPERATIONS = tuple(getattr(exp, n) for n in ("SetOperation", "Union", "Intersect", "Except") if hasattr(exp, n))

MAX_SQL_LENGTH = 6000


def _mask_literals(sql: str) -> str:
    """Remplace le texte entre quotes / crochets par un vide (pour analyser le reste)."""
    sql = re.sub(r"'(?:[^']|'')*'", "''", sql)
    sql = re.sub(r"\[[^\]]*\]", "[]", sql)
    sql = re.sub(r'"[^"]*"', '""', sql)
    return sql


def check_sql(sql: str, max_rows: int = 500, allowed_tables=ALLOWED_TABLES, dialect: str = "tsql") -> str:
    if sql is None or not str(sql).strip():
        raise SQLGuardError("La requête est vide.")
    sql = str(sql).strip()
    if len(sql) > MAX_SQL_LENGTH:
        raise SQLGuardError("La requête est trop longue.")
    sql = sql.rstrip(";").strip()
    masked = _mask_literals(sql)

    # 1. Syntaxe interdite (regex) -------------------------------------------------------------
    if "--" in masked or "/*" in masked or "*/" in masked:
        raise SQLGuardError("Les commentaires SQL sont interdits.")
    if ";" in masked:
        raise SQLGuardError("Une seule requête est autorisée (pas de point-virgule).")
    if not re.match(r"^\s*\(*\s*(select|with)\b", masked, re.I):
        raise SQLGuardError("Seules les requêtes SELECT sont autorisées.")
    for word in FORBIDDEN_WORDS:
        if re.search(rf"\b{re.escape(word)}\b", masked, re.I):
            raise SQLGuardError(f"Mot-clé interdit : {word.upper()}.")
    if re.search(r"\b(xp|sp|fn)_\w+", masked, re.I):
        raise SQLGuardError("Les procédures système sont interdites.")
    if re.search(r"@@?\w+", masked):
        raise SQLGuardError("Les variables SQL (@...) sont interdites.")

    # 2. Analyse syntaxique (sqlglot) ----------------------------------------------------------
    try:
        statements = sqlglot.parse(sql, read="tsql")
    except SqlglotError:
        raise SQLGuardError("La requête n'est pas du SQL Server valide.")
    statements = [s for s in statements if s is not None]
    if len(statements) != 1:
        raise SQLGuardError("Une seule requête est autorisée.")
    tree = statements[0]
    if not isinstance(tree, (exp.Select, exp.Subquery) + SET_OPERATIONS):
        raise SQLGuardError("Seules les requêtes SELECT sont autorisées.")
    for node in tree.walk():
        if isinstance(node, FORBIDDEN_NODES):
            raise SQLGuardError("Cette requête n'est pas en lecture seule.")
        if isinstance(node, exp.Select) and node.args.get("into"):
            raise SQLGuardError("SELECT ... INTO est interdit.")
        if isinstance(node, exp.Anonymous) and re.match(r"(xp|sp|fn)_|open", str(node.name), re.I):
            raise SQLGuardError(f"Fonction interdite : {node.name}.")

    # 3. Tables autorisées uniquement ----------------------------------------------------------
    allowed = {t.lower() for t in allowed_tables}
    cte_names = {c.alias.lower() for c in tree.find_all(exp.CTE) if c.alias}
    for table in tree.find_all(exp.Table):
        if not isinstance(table.this, exp.Identifier):
            raise SQLGuardError("Fonction de table interdite dans FROM.")
        name = table.name.lower()
        schema = (table.db or "").lower()
        if table.catalog or (schema and schema != "dbo"):
            raise SQLGuardError(f"Accès interdit à {table.db}.{table.name}.")
        if name not in allowed and name not in cte_names:
            raise SQLGuardError(f"Table non autorisée : {table.name}.")

    # 4. Limite de lignes imposée (TOP n) ------------------------------------------------------
    if isinstance(tree, exp.Select):
        limit = tree.args.get("limit")
        n = None
        if limit is not None and isinstance(limit.expression, exp.Literal) and not limit.expression.is_string:
            try:
                n = int(limit.expression.this)
            except ValueError:
                n = None
        if limit is None or n is None or n > max_rows or "PERCENT" in limit.sql().upper():
            tree.set("limit", exp.Limit(expression=exp.Literal.number(max_rows)))
        try:
            safe_sql = tree.sql(dialect=dialect)      # TOP n pour SQL Server (tsql)
        except SqlglotError:
            raise SQLGuardError("Impossible de normaliser la requête.")
    else:
        safe_sql = sql          # UNION : limite appliquée côté client (fetchmany)

    # 5. Re-vérification du SQL final -----------------------------------------------------------
    try:
        again = [s for s in sqlglot.parse(safe_sql, read=dialect) if s is not None]
    except SqlglotError:
        raise SQLGuardError("La requête normalisée est invalide.")
    if len(again) != 1 or not isinstance(again[0], (exp.Select, exp.Subquery) + SET_OPERATIONS):
        raise SQLGuardError("La requête normalisée est invalide.")
    return safe_sql


def is_safe(sql: str, **kw):
    """(True, sql_propre) ou (False, message)."""
    try:
        return True, check_sql(sql, **kw)
    except SQLGuardError as e:
        return False, str(e)
