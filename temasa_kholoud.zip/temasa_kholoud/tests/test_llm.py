import pytest
import requests

import llm


def test_clean_key_strips_spaces_quotes_and_prefix():
    assert llm.clean_key('  "sk-ant-abc \n def"  ') == "sk-ant-abcdef"
    assert llm.clean_key("Bearer sk-ant-xyz") == "sk-ant-xyz"
    assert llm.clean_key(None) == ""


@pytest.mark.parametrize("prov,key,ok", [
    ("anthropic", "", False), ("anthropic", "votre_cle", False), ("anthropic", "abc123", False),
    ("anthropic", "sk-ant-api03-" + "x" * 30, True),
    ("gemini", "", False), ("gemini", "court", False), ("gemini", "AIza" + "x" * 35, True),
])
def test_validate_key(prov, key, ok):
    assert (llm.validate_key(prov, key) is None) == ok


class FakeResponse:
    def __init__(self, status, body):
        self.status_code, self._body = status, body

    def json(self):
        return self._body


def _env(monkeypatch, prov="anthropic"):
    monkeypatch.setattr(llm.settings, "get", lambda n, d=None: {"LLM_PROVIDER": prov, "ANTHROPIC_API_KEY": "sk-ant-api03-" + "k" * 30,
                                                              "GEMINI_API_KEY": "AIza" + "k" * 35}.get(n, d))


def test_401_gives_friendly_message_without_secret(monkeypatch):
    _env(monkeypatch)
    monkeypatch.setattr(requests, "post", lambda *a, **k: FakeResponse(401, {"error": {"message": "invalid x-api-key"}}))
    with pytest.raises(llm.LLMError) as e:
        llm.complete("s", [{"role": "user", "content": "hi"}])
    assert "console.anthropic.com" in str(e.value) and "sk-ant-api03-kkkk" not in str(e.value)


def test_gemini_invalid_key_is_detected(monkeypatch):
    _env(monkeypatch, "gemini")
    monkeypatch.setattr(requests, "post", lambda *a, **k: FakeResponse(400, {"error": {"message": "API key not valid", "status": "INVALID_ARGUMENT"}}))
    with pytest.raises(llm.LLMError, match="aistudio.google.com"):
        llm.complete("s", [{"role": "user", "content": "hi"}])


def test_quota_and_network_errors(monkeypatch):
    _env(monkeypatch)
    monkeypatch.setattr(requests, "post", lambda *a, **k: FakeResponse(429, {}))
    with pytest.raises(llm.LLMError, match="Limite"):
        llm.complete("s", [{"role": "user", "content": "hi"}])

    def boom(*a, **k):
        raise requests.exceptions.ConnectionError("x")
    monkeypatch.setattr(requests, "post", boom)
    with pytest.raises(llm.LLMError, match="Internet"):
        llm.complete("s", [{"role": "user", "content": "hi"}])


def test_missing_key_never_calls_network(monkeypatch):
    monkeypatch.setattr(llm.settings, "get", lambda n, d=None: {"LLM_PROVIDER": "gemini"}.get(n, d))
    monkeypatch.setattr(requests, "post", lambda *a, **k: pytest.fail("réseau appelé sans clé"))
    with pytest.raises(llm.LLMError, match="GEMINI_API_KEY"):
        llm.complete("s", [{"role": "user", "content": "hi"}])


def test_parse_llm_json():
    assert llm.parse_llm_json('```json\n{"sql": "SELECT 1", "reply": null}\n```')["sql"] == "SELECT 1"
    assert llm.parse_llm_json('Voici : {"sql": null, "reply": "précisez"} merci')["reply"] == "précisez"
