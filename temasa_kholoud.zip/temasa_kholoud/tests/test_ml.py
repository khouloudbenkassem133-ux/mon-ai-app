import numpy as np
import pandas as pd
import pytest

import ml


def fake_production(days=400, seed=0):
    rng = np.random.default_rng(seed)
    rows = []
    for d in pd.date_range("2025-01-01", periods=days):
        if d.dayofweek == 6:
            continue
        for m in ["MC-01", "MC-02", "MC-03"]:
            for sh in ["Matin", "Nuit"]:
                prod = int(rng.normal(3000, 100))
                rate = 0.06 if m == "MC-03" else 0.02
                rows.append(dict(date=d, machine_code=m, shift_name=sh, category="Chaussettes", target_group="Homme",
                                 qty_planned=3100, qty_produced=prod, qty_rejected=int(rng.binomial(prod, rate)),
                                 run_hours=7.5, downtime_hours=0.5))
    return pd.DataFrame(rows)


def test_too_little_data_is_refused():
    p = fake_production(days=60)
    with pytest.raises(ml.MLDataError, match="au moins"):
        ml.train_forecast(p, "production", "M", p.date.min(), p.date.max())
    with pytest.raises(ml.MLDataError):
        ml.train_classif_scrap(p.head(100), p.date.min(), p.date.max())


def test_missing_column_is_reported_not_invented():
    p = fake_production().drop(columns=["downtime_hours"])
    with pytest.raises(ml.MLDataError, match="downtime_hours"):
        ml.train_scrap_drivers(p, p.date.min(), p.date.max())


def test_scrap_driver_finds_the_bad_machine():
    p = fake_production()
    res, _ = ml.train_scrap_drivers(p, p.date.min(), p.date.max())
    top = res["coefs"].iloc[0]
    assert "MC-03" in top["Variable"] and top["Coefficient (points de %)"] > 2 and top["p-value"] < 0.001


def test_time_split_has_no_leakage():
    p = fake_production()
    train, test, cutoff = ml._split_by_date(p, "date")
    assert train["date"].max() < test["date"].min()


def test_classifier_and_forecast_run_with_time_split():
    p = fake_production()
    res, _ = ml.train_classif_scrap(p, p.date.min(), p.date.max(), 4.0)
    assert res["models"]["Random Forest"]["auc"] > 0.95 and res["info"]["cutoff"]
    fc, _ = ml.train_forecast(p, "production", "W", p.date.min(), p.date.max(), horizon=4)
    assert len(fc["forecasts"]["Régression linéaire"]) == 4 and fc["metrics"].shape[0] == 4


def test_anomaly_detection_flags_an_injected_outlier():
    p = fake_production()
    i = p[(p.machine_code == "MC-01") & (p.date == "2025-09-10")].index
    p.loc[i, "qty_produced"] = 200
    p.loc[i, "qty_rejected"] = 150
    res, _ = ml.train_anomalies(p, p.date.min(), p.date.max(), 0.01)
    f = res["flagged"]
    assert ((f.machine_code == "MC-01") & (f.date == "2025-09-10")).any()
