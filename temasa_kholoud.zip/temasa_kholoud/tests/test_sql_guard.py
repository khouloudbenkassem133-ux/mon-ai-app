import pytest

from sql_guard import SQLGuardError, check_sql

DANGEROUS = [
    "DROP TABLE dim_machine",
    "DELETE FROM fact_orders",
    "UPDATE dim_machine SET machine_code = 'x'",
    "INSERT INTO dim_client VALUES (99, 'x', 'x', 'x', 'x')",
    "TRUNCATE TABLE fact_stock",
    "ALTER TABLE dim_machine ADD x INT",
    "CREATE TABLE t (a INT)",
    "MERGE dim_machine AS t USING dim_machine AS s ON 1=1 WHEN MATCHED THEN DELETE",
    "EXEC xp_cmdshell 'dir'",
    "EXECUTE sp_who",
    "SELECT * FROM dim_machine; DROP TABLE dim_machine",
    "SELECT * FROM dim_machine; SELECT * FROM dim_client",
    "SELECT * FROM dim_machine -- commentaire",
    "SELECT * FROM dim_machine /* x */",
    "SELECT * INTO copie FROM dim_machine",
    "SELECT * FROM sys.tables",
    "SELECT * FROM information_schema.tables",
    "SELECT name FROM master.dbo.sysdatabases",
    "SELECT * FROM OPENROWSET('SQLNCLI', 'Server=x;', 'SELECT 1')",
    "SELECT * FROM mon_autre_table",
    "SELECT * FROM dim_machine WHERE 1=1 UNION SELECT name, 1, 1, 1 FROM sys.objects",
    "WITH x AS (SELECT * FROM sys.tables) SELECT * FROM x",
    "SELECT * FROM dim_machine WHERE machine_code = @x",
    "DECLARE @a INT = 1 SELECT @a",
    "SET ROWCOUNT 1000000",
    "USE master",
    "GRANT SELECT ON dim_machine TO public",
    "BACKUP DATABASE temasa_dw TO DISK = 'c:\\x.bak'",
    "",
    "   ",
    "SELECT 1 FROM dim_machine WHERE (",
    "SHUTDOWN",
]

SAFE = [
    "SELECT TOP (5) * FROM dim_machine",
    "SELECT machine_code FROM dim_machine ORDER BY machine_code;",
    "WITH x AS (SELECT machine_key, SUM(qty_produced) AS p FROM fact_production GROUP BY machine_key) "
    "SELECT m.machine_code, x.p FROM x JOIN dim_machine m ON m.machine_key = x.machine_key",
    "SELECT date_key / 100 AS ym, SUM(qty_produced) AS produit FROM fact_production GROUP BY date_key / 100 ORDER BY ym",
    "SELECT CAST(100.0 * SUM(qty_rejected) / NULLIF(SUM(qty_produced), 0) AS DECIMAL(5,2)) AS taux FROM fact_production",
    "SELECT product_name FROM dim_product WHERE product_name LIKE '%update%'",   # mot interdit dans une chaîne : OK
    "SELECT * FROM dbo.vw_orders",
    "SELECT machine_code FROM dim_machine UNION ALL SELECT client_code FROM dim_client",
    "SELECT d.defect_name, SUM(q.qty_defective) AS n, "
    "100.0 * SUM(q.qty_defective) / SUM(SUM(q.qty_defective)) OVER () AS pct "
    "FROM fact_quality q JOIN dim_defect_type d ON d.defect_type_key = q.defect_type_key GROUP BY d.defect_name",
]


@pytest.mark.parametrize("sql", DANGEROUS)
def test_dangerous_queries_are_rejected(sql):
    with pytest.raises(SQLGuardError):
        check_sql(sql)


@pytest.mark.parametrize("sql", SAFE)
def test_safe_queries_are_accepted(sql):
    out = check_sql(sql)
    assert out.upper().startswith(("SELECT", "WITH", "("))


def test_row_limit_is_added():
    assert "TOP 500" in check_sql("SELECT * FROM fact_production", max_rows=500).upper()


def test_row_limit_is_capped():
    assert "TOP 500" in check_sql("SELECT TOP (100000) * FROM fact_production", max_rows=500).upper()


def test_smaller_limit_is_kept():
    assert "TOP 5" in check_sql("SELECT TOP (5) * FROM fact_production", max_rows=500).upper()


def test_error_messages_are_french():
    with pytest.raises(SQLGuardError, match="interdit|autoris|vide|valide"):
        check_sql("DROP TABLE x")
